# This file was automatically created by FeynRules 2.3.49
# Mathematica version: 14.3.0 for Linux x86 (64-bit) (July 8, 2025)
# Date: Mon 3 Aug 2026 11:03:21


from .object_library import all_orders, CouplingOrder


QED = CouplingOrder(name = 'QED',
                    expansion_order = 99,
                    hierarchy = 1)

QCD = CouplingOrder(name = 'QCD',
                    expansion_order = 0,
                    hierarchy = 1)

