# This file was automatically created by FeynRules 2.3.49
# Mathematica version: 14.3.0 for Linux x86 (64-bit) (July 8, 2025)
# Date: Mon 3 Aug 2026 11:03:21


from __future__ import absolute_import

from .object_library import all_parameters, Parameter


from .function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot

# This is a default parameter object representing 0.
ZERO = Parameter(name = 'ZERO',
                 nature = 'internal',
                 type = 'real',
                 value = '0.0',
                 texname = '0')

# User-defined parameters.
AD = Parameter(name = 'AD',
               nature = 'external',
               type = 'real',
               value = -1,
               texname = '\\text{AD}',
               lhablock = 'CHIPTDELTA',
               lhacode = [ 1 ])

gD = Parameter(name = 'gD',
               nature = 'external',
               type = 'real',
               value = 1,
               texname = '\\text{gD}',
               lhablock = 'CHIPTDELTA',
               lhacode = [ 2 ])

g1D = Parameter(name = 'g1D',
                nature = 'external',
                type = 'real',
                value = 1,
                texname = '\\text{g1D}',
                lhablock = 'CHIPTDELTA',
                lhacode = [ 3 ])

hD = Parameter(name = 'hD',
               nature = 'external',
               type = 'real',
               value = 0.76,
               texname = '\\text{hD}',
               lhablock = 'CHIPTDELTA',
               lhacode = [ 4 ])

G1 = Parameter(name = 'G1',
               nature = 'external',
               type = 'real',
               value = 6.061,
               texname = '\\text{G1}',
               lhablock = 'CHIPTDELTA',
               lhacode = [ 5 ])

G2 = Parameter(name = 'G2',
               nature = 'external',
               type = 'real',
               value = 2.414,
               texname = '\\text{G2}',
               lhablock = 'CHIPTDELTA',
               lhacode = [ 6 ])

LambdaFF = Parameter(name = 'LambdaFF',
                     nature = 'external',
                     type = 'real',
                     value = 1.121,
                     texname = '\\text{LambdaFF}',
                     lhablock = 'CHIPTFF',
                     lhacode = [ 1 ])

fPi = Parameter(name = 'fPi',
                nature = 'external',
                type = 'real',
                value = 0.093,
                texname = '\\text{fPi}',
                lhablock = 'CHIPTPION',
                lhacode = [ 1 ])

ga = Parameter(name = 'ga',
               nature = 'external',
               type = 'real',
               value = 1.271,
               texname = '\\text{ga}',
               lhablock = 'CHIPTPION',
               lhacode = [ 2 ])

cabi = Parameter(name = 'cabi',
                 nature = 'external',
                 type = 'real',
                 value = 0.227736,
                 texname = '\\theta _c',
                 lhablock = 'CKMBLOCK',
                 lhacode = [ 1 ])

aEWM1 = Parameter(name = 'aEWM1',
                  nature = 'external',
                  type = 'real',
                  value = 137.035999,
                  texname = '\\text{aEWM1}',
                  lhablock = 'SMINPUTS',
                  lhacode = [ 1 ])

Gf = Parameter(name = 'Gf',
               nature = 'external',
               type = 'real',
               value = 0.0000116637,
               texname = 'G_f',
               lhablock = 'SMINPUTS',
               lhacode = [ 2 ])

yme = Parameter(name = 'yme',
                nature = 'external',
                type = 'real',
                value = 0.000511,
                texname = '\\text{yme}',
                lhablock = 'YUKAWA',
                lhacode = [ 11 ])

ymm = Parameter(name = 'ymm',
                nature = 'external',
                type = 'real',
                value = 0.10566,
                texname = '\\text{ymm}',
                lhablock = 'YUKAWA',
                lhacode = [ 13 ])

ymtau = Parameter(name = 'ymtau',
                  nature = 'external',
                  type = 'real',
                  value = 1.777,
                  texname = '\\text{ymtau}',
                  lhablock = 'YUKAWA',
                  lhacode = [ 15 ])

MZ = Parameter(name = 'MZ',
               nature = 'external',
               type = 'real',
               value = 91.1876,
               texname = '\\text{MZ}',
               lhablock = 'MASS',
               lhacode = [ 23 ])

Me = Parameter(name = 'Me',
               nature = 'external',
               type = 'real',
               value = 0.000511,
               texname = '\\text{Me}',
               lhablock = 'MASS',
               lhacode = [ 11 ])

MMU = Parameter(name = 'MMU',
                nature = 'external',
                type = 'real',
                value = 0.10566,
                texname = '\\text{MMU}',
                lhablock = 'MASS',
                lhacode = [ 13 ])

MTA = Parameter(name = 'MTA',
                nature = 'external',
                type = 'real',
                value = 1.777,
                texname = '\\text{MTA}',
                lhablock = 'MASS',
                lhacode = [ 15 ])

MNucleon = Parameter(name = 'MNucleon',
                     nature = 'external',
                     type = 'real',
                     value = 0.938272,
                     texname = '\\text{MNucleon}',
                     lhablock = 'MASS',
                     lhacode = [ 2112 ])

MH = Parameter(name = 'MH',
               nature = 'external',
               type = 'real',
               value = 125,
               texname = '\\text{MH}',
               lhablock = 'MASS',
               lhacode = [ 25 ])

MPi0 = Parameter(name = 'MPi0',
                 nature = 'external',
                 type = 'real',
                 value = 0.1349768,
                 texname = '\\text{MPi0}',
                 lhablock = 'MASS',
                 lhacode = [ 111 ])

MPiP = Parameter(name = 'MPiP',
                 nature = 'external',
                 type = 'real',
                 value = 0.1395704,
                 texname = '\\text{MPiP}',
                 lhablock = 'MASS',
                 lhacode = [ 211 ])

MEta = Parameter(name = 'MEta',
                 nature = 'external',
                 type = 'real',
                 value = 0.547862,
                 texname = '\\text{MEta}',
                 lhablock = 'MASS',
                 lhacode = [ 221 ])

MK0 = Parameter(name = 'MK0',
                nature = 'external',
                type = 'real',
                value = 0.497611,
                texname = '\\text{MK0}',
                lhablock = 'MASS',
                lhacode = [ 311 ])

MKp = Parameter(name = 'MKp',
                nature = 'external',
                type = 'real',
                value = 0.493677,
                texname = '\\text{MKp}',
                lhablock = 'MASS',
                lhacode = [ 321 ])

MDelta = Parameter(name = 'MDelta',
                   nature = 'external',
                   type = 'real',
                   value = 1.209,
                   texname = '\\text{MDelta}',
                   lhablock = 'MASS',
                   lhacode = [ 1114 ])

WZ = Parameter(name = 'WZ',
               nature = 'external',
               type = 'real',
               value = 2.4952,
               texname = '\\text{WZ}',
               lhablock = 'DECAY',
               lhacode = [ 23 ])

WW = Parameter(name = 'WW',
               nature = 'external',
               type = 'real',
               value = 2.085,
               texname = '\\text{WW}',
               lhablock = 'DECAY',
               lhacode = [ 24 ])

WH = Parameter(name = 'WH',
               nature = 'external',
               type = 'real',
               value = 0.00407,
               texname = '\\text{WH}',
               lhablock = 'DECAY',
               lhacode = [ 25 ])

WPi0 = Parameter(name = 'WPi0',
                 nature = 'external',
                 type = 'real',
                 value = 0.,
                 texname = '\\text{WPi0}',
                 lhablock = 'DECAY',
                 lhacode = [ 111 ])

WPiP = Parameter(name = 'WPiP',
                 nature = 'external',
                 type = 'real',
                 value = 0.,
                 texname = '\\text{WPiP}',
                 lhablock = 'DECAY',
                 lhacode = [ 211 ])

WEta = Parameter(name = 'WEta',
                 nature = 'external',
                 type = 'real',
                 value = 0.,
                 texname = '\\text{WEta}',
                 lhablock = 'DECAY',
                 lhacode = [ 221 ])

WK0 = Parameter(name = 'WK0',
                nature = 'external',
                type = 'real',
                value = 0.,
                texname = '\\text{WK0}',
                lhablock = 'DECAY',
                lhacode = [ 311 ])

WKp = Parameter(name = 'WKp',
                nature = 'external',
                type = 'real',
                value = 0.,
                texname = '\\text{WKp}',
                lhablock = 'DECAY',
                lhacode = [ 321 ])

WDeltaPP = Parameter(name = 'WDeltaPP',
                     nature = 'external',
                     type = 'real',
                     value = 0.102,
                     texname = '\\text{WDeltaPP}',
                     lhablock = 'DECAY',
                     lhacode = [ 2224 ])

WDeltaP = Parameter(name = 'WDeltaP',
                    nature = 'external',
                    type = 'real',
                    value = 0.102,
                    texname = '\\text{WDeltaP}',
                    lhablock = 'DECAY',
                    lhacode = [ 2214 ])

WDelta0 = Parameter(name = 'WDelta0',
                    nature = 'external',
                    type = 'real',
                    value = 0.102,
                    texname = '\\text{WDelta0}',
                    lhablock = 'DECAY',
                    lhacode = [ 2114 ])

WDeltaM = Parameter(name = 'WDeltaM',
                    nature = 'external',
                    type = 'real',
                    value = 0.102,
                    texname = '\\text{WDeltaM}',
                    lhablock = 'DECAY',
                    lhacode = [ 1114 ])

MPi = Parameter(name = 'MPi',
                nature = 'internal',
                type = 'real',
                value = 'MPi0',
                texname = '\\text{MPi}')

g2D = Parameter(name = 'g2D',
                nature = 'internal',
                type = 'real',
                value = 'AD*g1D',
                texname = '\\text{g2D}')

g3D = Parameter(name = 'g3D',
                nature = 'internal',
                type = 'real',
                value = '((-1 - 2*AD - 3*AD**2)*g1D)/2.',
                texname = '\\text{g3D}')

ztilde = Parameter(name = 'ztilde',
                   nature = 'internal',
                   type = 'real',
                   value = '(1 + 3*AD)/2.',
                   texname = '\\text{ztilde}')

aEW = Parameter(name = 'aEW',
                nature = 'internal',
                type = 'real',
                value = '1/aEWM1',
                texname = '\\alpha _{\\text{EW}}')

CKM1x1 = Parameter(name = 'CKM1x1',
                   nature = 'internal',
                   type = 'complex',
                   value = 'cmath.cos(cabi)',
                   texname = '\\text{CKM1x1}')

CKM1x2 = Parameter(name = 'CKM1x2',
                   nature = 'internal',
                   type = 'complex',
                   value = 'cmath.sin(cabi)',
                   texname = '\\text{CKM1x2}')

CKM1x3 = Parameter(name = 'CKM1x3',
                   nature = 'internal',
                   type = 'complex',
                   value = '0',
                   texname = '\\text{CKM1x3}')

CKM2x1 = Parameter(name = 'CKM2x1',
                   nature = 'internal',
                   type = 'complex',
                   value = '-cmath.sin(cabi)',
                   texname = '\\text{CKM2x1}')

CKM2x2 = Parameter(name = 'CKM2x2',
                   nature = 'internal',
                   type = 'complex',
                   value = 'cmath.cos(cabi)',
                   texname = '\\text{CKM2x2}')

CKM2x3 = Parameter(name = 'CKM2x3',
                   nature = 'internal',
                   type = 'complex',
                   value = '0',
                   texname = '\\text{CKM2x3}')

CKM3x1 = Parameter(name = 'CKM3x1',
                   nature = 'internal',
                   type = 'complex',
                   value = '0',
                   texname = '\\text{CKM3x1}')

CKM3x2 = Parameter(name = 'CKM3x2',
                   nature = 'internal',
                   type = 'complex',
                   value = '0',
                   texname = '\\text{CKM3x2}')

CKM3x3 = Parameter(name = 'CKM3x3',
                   nature = 'internal',
                   type = 'complex',
                   value = '1',
                   texname = '\\text{CKM3x3}')

MW = Parameter(name = 'MW',
               nature = 'internal',
               type = 'real',
               value = 'cmath.sqrt(MZ**2/2. + cmath.sqrt(MZ**4/4. - (aEW*cmath.pi*MZ**2)/(Gf*cmath.sqrt(2))))',
               texname = 'M_W')

ee = Parameter(name = 'ee',
               nature = 'internal',
               type = 'real',
               value = '2*cmath.sqrt(aEW)*cmath.sqrt(cmath.pi)',
               texname = 'e')

sw2 = Parameter(name = 'sw2',
                nature = 'internal',
                type = 'real',
                value = '1 - MW**2/MZ**2',
                texname = '\\text{sw2}')

Kappa = Parameter(name = 'Kappa',
                  nature = 'internal',
                  type = 'real',
                  value = '(3*ee)/(2.*MNucleon*(MDelta + MNucleon))',
                  texname = '\\text{Kappa}')

cw = Parameter(name = 'cw',
               nature = 'internal',
               type = 'real',
               value = 'cmath.sqrt(1 - sw2)',
               texname = 'c_w')

sw = Parameter(name = 'sw',
               nature = 'internal',
               type = 'real',
               value = 'cmath.sqrt(sw2)',
               texname = 's_w')

g1 = Parameter(name = 'g1',
               nature = 'internal',
               type = 'real',
               value = 'ee/cw',
               texname = 'g_1')

g2 = Parameter(name = 'g2',
               nature = 'internal',
               type = 'real',
               value = 'ee/sw',
               texname = 'g_w')

vev = Parameter(name = 'vev',
                nature = 'internal',
                type = 'real',
                value = '(2*MW*sw)/ee',
                texname = '\\text{vev}')

lam = Parameter(name = 'lam',
                nature = 'internal',
                type = 'real',
                value = 'MH**2/(2.*vev**2)',
                texname = '\\text{lam}')

ye = Parameter(name = 'ye',
               nature = 'internal',
               type = 'real',
               value = '(yme*cmath.sqrt(2))/vev',
               texname = '\\text{ye}')

ym = Parameter(name = 'ym',
               nature = 'internal',
               type = 'real',
               value = '(ymm*cmath.sqrt(2))/vev',
               texname = '\\text{ym}')

ytau = Parameter(name = 'ytau',
                 nature = 'internal',
                 type = 'real',
                 value = '(ymtau*cmath.sqrt(2))/vev',
                 texname = '\\text{ytau}')

muH = Parameter(name = 'muH',
                nature = 'internal',
                type = 'real',
                value = 'cmath.sqrt(lam*vev**2)',
                texname = '\\mu')

