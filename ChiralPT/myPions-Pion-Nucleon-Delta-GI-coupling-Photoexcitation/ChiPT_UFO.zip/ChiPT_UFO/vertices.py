# This file was automatically created by FeynRules 2.3.49
# Mathematica version: 14.3.0 for Linux x86 (64-bit) (July 8, 2025)
# Date: Mon 3 Aug 2026 11:03:21


from __future__ import absolute_import
from .object_library import all_vertices, Vertex
from . import particles as P
from . import couplings as C
from . import lorentz as L


V_1 = Vertex(name = 'V_1',
             particles = [ P.H, P.H, P.H, P.H ],
             color = [ '1' ],
             lorentz = [ L.SSSS1 ],
             couplings = {(0,0):C.GC_53})

V_2 = Vertex(name = 'V_2',
             particles = [ P.H, P.H, P.H ],
             color = [ '1' ],
             lorentz = [ L.SSS1 ],
             couplings = {(0,0):C.GC_169})

V_3 = Vertex(name = 'V_3',
             particles = [ P.A, P.A, P.Pi__minus__, P.Pi__plus__ ],
             color = [ '1' ],
             lorentz = [ L.VVSS1 ],
             couplings = {(0,0):C.GC_12})

V_4 = Vertex(name = 'V_4',
             particles = [ P.Pi0, P.Pi0, P.Pi0, P.Pi0 ],
             color = [ '1' ],
             lorentz = [ L.SSSS4 ],
             couplings = {(0,0):C.GC_21})

V_5 = Vertex(name = 'V_5',
             particles = [ P.A, P.Pi__minus__, P.Pi__plus__ ],
             color = [ '1' ],
             lorentz = [ L.VSS1 ],
             couplings = {(0,0):C.GC_3})

V_6 = Vertex(name = 'V_6',
             particles = [ P.Pi0, P.Pi0, P.Pi__minus__, P.Pi__plus__ ],
             color = [ '1' ],
             lorentz = [ L.SSSS2 ],
             couplings = {(0,0):C.GC_20})

V_7 = Vertex(name = 'V_7',
             particles = [ P.Pi__minus__, P.Pi__minus__, P.Pi__plus__, P.Pi__plus__ ],
             color = [ '1' ],
             lorentz = [ L.SSSS3 ],
             couplings = {(0,0):C.GC_21})

V_8 = Vertex(name = 'V_8',
             particles = [ P.p__tilde__, P.p, P.A ],
             color = [ '1' ],
             lorentz = [ L.FFV1 ],
             couplings = {(0,0):C.GC_4})

V_9 = Vertex(name = 'V_9',
             particles = [ P.Delta0__tilde__, P.Delta0, P.Pi__minus__, P.Pi__plus__ ],
             color = [ '1' ],
             lorentz = [ L.RRSS1, L.RRSS2, L.RRSS3 ],
             couplings = {(0,1):C.GC_27,(0,2):C.GC_15,(0,0):C.GC_35})

V_10 = Vertex(name = 'V_10',
              particles = [ P.Delta__minus____tilde__, P.Delta0, P.Pi0, P.Pi__minus__ ],
              color = [ '1' ],
              lorentz = [ L.RRSS1, L.RRSS2, L.RRSS3 ],
              couplings = {(0,1):C.GC_30,(0,2):C.GC_22,(0,0):C.GC_38})

V_11 = Vertex(name = 'V_11',
              particles = [ P.Delta0__tilde__, P.Delta__minus__, P.Pi0, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.RRSS1, L.RRSS2, L.RRSS3 ],
              couplings = {(0,1):C.GC_31,(0,2):C.GC_23,(0,0):C.GC_39})

V_12 = Vertex(name = 'V_12',
              particles = [ P.Delta__minus____tilde__, P.Delta__minus__, P.A ],
              color = [ '1' ],
              lorentz = [ L.RRV1, L.RRV2, L.RRV3 ],
              couplings = {(0,1):C.GC_2,(0,2):C.GC_6,(0,0):C.GC_9})

V_13 = Vertex(name = 'V_13',
              particles = [ P.Delta__minus____tilde__, P.Delta__minus__, P.Pi__minus__, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.RRSS1, L.RRSS2, L.RRSS3 ],
              couplings = {(0,1):C.GC_29,(0,2):C.GC_19,(0,0):C.GC_37})

V_14 = Vertex(name = 'V_14',
              particles = [ P.Delta__plus____tilde__, P.Delta0, P.Pi0, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.RRSS1, L.RRSS2, L.RRSS3 ],
              couplings = {(0,1):C.GC_33,(0,2):C.GC_25,(0,0):C.GC_41})

V_15 = Vertex(name = 'V_15',
              particles = [ P.Delta0__tilde__, P.Delta__plus__, P.Pi0, P.Pi__minus__ ],
              color = [ '1' ],
              lorentz = [ L.RRSS1, L.RRSS2, L.RRSS3 ],
              couplings = {(0,1):C.GC_32,(0,2):C.GC_24,(0,0):C.GC_40})

V_16 = Vertex(name = 'V_16',
              particles = [ P.Delta__plus____tilde__, P.Delta__plus__, P.A ],
              color = [ '1' ],
              lorentz = [ L.RRV1, L.RRV2, L.RRV3 ],
              couplings = {(0,1):C.GC_1,(0,2):C.GC_5,(0,0):C.GC_8})

V_17 = Vertex(name = 'V_17',
              particles = [ P.Delta__plus____tilde__, P.Delta__plus__, P.Pi__minus__, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.RRSS1, L.RRSS2, L.RRSS3 ],
              couplings = {(0,1):C.GC_26,(0,2):C.GC_14,(0,0):C.GC_34})

V_18 = Vertex(name = 'V_18',
              particles = [ P.Delta__plus____plus____tilde__, P.Delta__plus__, P.Pi0, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.RRSS1, L.RRSS2, L.RRSS3 ],
              couplings = {(0,1):C.GC_31,(0,2):C.GC_23,(0,0):C.GC_39})

V_19 = Vertex(name = 'V_19',
              particles = [ P.Delta__plus____tilde__, P.Delta__plus____plus__, P.Pi0, P.Pi__minus__ ],
              color = [ '1' ],
              lorentz = [ L.RRSS1, L.RRSS2, L.RRSS3 ],
              couplings = {(0,1):C.GC_30,(0,2):C.GC_22,(0,0):C.GC_38})

V_20 = Vertex(name = 'V_20',
              particles = [ P.Delta__plus____plus____tilde__, P.Delta__plus____plus__, P.A ],
              color = [ '1' ],
              lorentz = [ L.RRV1, L.RRV2, L.RRV3 ],
              couplings = {(0,1):C.GC_3,(0,2):C.GC_7,(0,0):C.GC_10})

V_21 = Vertex(name = 'V_21',
              particles = [ P.Delta__plus____plus____tilde__, P.Delta__plus____plus__, P.Pi__minus__, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.RRSS1, L.RRSS2, L.RRSS3 ],
              couplings = {(0,1):C.GC_28,(0,2):C.GC_18,(0,0):C.GC_36})

V_22 = Vertex(name = 'V_22',
              particles = [ P.n__tilde__, P.Delta0, P.A ],
              color = [ '1' ],
              lorentz = [ L.FRV2, L.FRV3 ],
              couplings = {(0,1):C.GC_51,(0,0):C.GC_49})

V_23 = Vertex(name = 'V_23',
              particles = [ P.Delta0__tilde__, P.n, P.A ],
              color = [ '1' ],
              lorentz = [ L.RFV2, L.RFV3 ],
              couplings = {(0,1):C.GC_52,(0,0):C.GC_50})

V_24 = Vertex(name = 'V_24',
              particles = [ P.n__tilde__, P.n, P.Pi__minus__, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.FFSS1 ],
              couplings = {(0,0):C.GC_16})

V_25 = Vertex(name = 'V_25',
              particles = [ P.e__plus__, P.e__minus__, P.H ],
              color = [ '1' ],
              lorentz = [ L.FFS2 ],
              couplings = {(0,0):C.GC_172})

V_26 = Vertex(name = 'V_26',
              particles = [ P.mu__plus__, P.mu__minus__, P.H ],
              color = [ '1' ],
              lorentz = [ L.FFS2 ],
              couplings = {(0,0):C.GC_173})

V_27 = Vertex(name = 'V_27',
              particles = [ P.ta__plus__, P.ta__minus__, P.H ],
              color = [ '1' ],
              lorentz = [ L.FFS2 ],
              couplings = {(0,0):C.GC_174})

V_28 = Vertex(name = 'V_28',
              particles = [ P.p__tilde__, P.Delta__plus__, P.A ],
              color = [ '1' ],
              lorentz = [ L.FRV2, L.FRV3 ],
              couplings = {(0,1):C.GC_51,(0,0):C.GC_49})

V_29 = Vertex(name = 'V_29',
              particles = [ P.p__tilde__, P.n, P.Pi0, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.FFSS1 ],
              couplings = {(0,0):C.GC_24})

V_30 = Vertex(name = 'V_30',
              particles = [ P.Delta__plus____tilde__, P.p, P.A ],
              color = [ '1' ],
              lorentz = [ L.RFV2, L.RFV3 ],
              couplings = {(0,1):C.GC_52,(0,0):C.GC_50})

V_31 = Vertex(name = 'V_31',
              particles = [ P.n__tilde__, P.p, P.Pi0, P.Pi__minus__ ],
              color = [ '1' ],
              lorentz = [ L.FFSS1 ],
              couplings = {(0,0):C.GC_25})

V_32 = Vertex(name = 'V_32',
              particles = [ P.p__tilde__, P.p, P.Pi__minus__, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.FFSS1 ],
              couplings = {(0,0):C.GC_17})

V_33 = Vertex(name = 'V_33',
              particles = [ P.A, P.W__minus__, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.VVS1 ],
              couplings = {(0,0):C.GC_109})

V_34 = Vertex(name = 'V_34',
              particles = [ P.A, P.W__minus__, P.Pi0, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.VVSS1 ],
              couplings = {(0,0):C.GC_76})

V_35 = Vertex(name = 'V_35',
              particles = [ P.W__minus__, P.Pi0, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.VSS1 ],
              couplings = {(0,0):C.GC_66})

V_36 = Vertex(name = 'V_36',
              particles = [ P.W__minus__, P.Pi0, P.Pi0, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.VSSS3 ],
              couplings = {(0,0):C.GC_78})

V_37 = Vertex(name = 'V_37',
              particles = [ P.W__minus__, P.Pi__minus__, P.Pi__plus__, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.VSSS1 ],
              couplings = {(0,0):C.GC_77})

V_38 = Vertex(name = 'V_38',
              particles = [ P.n__tilde__, P.p, P.W__minus__ ],
              color = [ '1' ],
              lorentz = [ L.FFV1, L.FFV2 ],
              couplings = {(0,1):C.GC_111,(0,0):C.GC_69})

V_39 = Vertex(name = 'V_39',
              particles = [ P.n__tilde__, P.n, P.W__minus__, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.FFVS1, L.FFVS2 ],
              couplings = {(0,1):C.GC_112,(0,0):C.GC_83})

V_40 = Vertex(name = 'V_40',
              particles = [ P.n__tilde__, P.p, P.W__minus__, P.Pi0 ],
              color = [ '1' ],
              lorentz = [ L.FFVS1, L.FFVS2 ],
              couplings = {(0,1):C.GC_114,(0,0):C.GC_88})

V_41 = Vertex(name = 'V_41',
              particles = [ P.p__tilde__, P.p, P.W__minus__, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.FFVS1, L.FFVS2 ],
              couplings = {(0,1):C.GC_113,(0,0):C.GC_80})

V_42 = Vertex(name = 'V_42',
              particles = [ P.Delta0__tilde__, P.Delta0, P.W__minus__, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.RRVS1, L.RRVS3, L.RRVS5 ],
              couplings = {(0,1):C.GC_82,(0,2):C.GC_91,(0,0):C.GC_99})

V_43 = Vertex(name = 'V_43',
              particles = [ P.Delta__minus____tilde__, P.Delta0, P.W__minus__ ],
              color = [ '1' ],
              lorentz = [ L.RRV1, L.RRV2, L.RRV3 ],
              couplings = {(0,1):C.GC_67,(0,2):C.GC_71,(0,0):C.GC_73})

V_44 = Vertex(name = 'V_44',
              particles = [ P.Delta__minus____tilde__, P.Delta0, P.W__minus__, P.Pi0 ],
              color = [ '1' ],
              lorentz = [ L.RRVS1, L.RRVS3, L.RRVS5 ],
              couplings = {(0,1):C.GC_86,(0,2):C.GC_94,(0,0):C.GC_102})

V_45 = Vertex(name = 'V_45',
              particles = [ P.Delta__minus____tilde__, P.Delta__minus__, P.W__minus__, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.RRVS1, L.RRVS3, L.RRVS5 ],
              couplings = {(0,1):C.GC_84,(0,2):C.GC_92,(0,0):C.GC_100})

V_46 = Vertex(name = 'V_46',
              particles = [ P.Delta0__tilde__, P.Delta__plus__, P.W__minus__ ],
              color = [ '1' ],
              lorentz = [ L.RRV1, L.RRV2, L.RRV3 ],
              couplings = {(0,1):C.GC_68,(0,2):C.GC_72,(0,0):C.GC_74})

V_47 = Vertex(name = 'V_47',
              particles = [ P.Delta0__tilde__, P.Delta__plus__, P.W__minus__, P.Pi0 ],
              color = [ '1' ],
              lorentz = [ L.RRVS1, L.RRVS3, L.RRVS5 ],
              couplings = {(0,1):C.GC_88,(0,2):C.GC_96,(0,0):C.GC_104})

V_48 = Vertex(name = 'V_48',
              particles = [ P.Delta__plus____tilde__, P.Delta__plus__, P.W__minus__, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.RRVS1, L.RRVS3, L.RRVS5 ],
              couplings = {(0,1):C.GC_81,(0,2):C.GC_90,(0,0):C.GC_98})

V_49 = Vertex(name = 'V_49',
              particles = [ P.Delta__plus____tilde__, P.Delta__plus____plus__, P.W__minus__ ],
              color = [ '1' ],
              lorentz = [ L.RRV1, L.RRV2, L.RRV3 ],
              couplings = {(0,1):C.GC_67,(0,2):C.GC_71,(0,0):C.GC_73})

V_50 = Vertex(name = 'V_50',
              particles = [ P.Delta__plus____tilde__, P.Delta__plus____plus__, P.W__minus__, P.Pi0 ],
              color = [ '1' ],
              lorentz = [ L.RRVS1, L.RRVS3, L.RRVS5 ],
              couplings = {(0,1):C.GC_86,(0,2):C.GC_94,(0,0):C.GC_102})

V_51 = Vertex(name = 'V_51',
              particles = [ P.Delta__plus____plus____tilde__, P.Delta__plus____plus__, P.W__minus__, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.RRVS1, L.RRVS3, L.RRVS5 ],
              couplings = {(0,1):C.GC_79,(0,2):C.GC_89,(0,0):C.GC_97})

V_52 = Vertex(name = 'V_52',
              particles = [ P.A, P.W__plus__, P.Pi__minus__ ],
              color = [ '1' ],
              lorentz = [ L.VVS1 ],
              couplings = {(0,0):C.GC_110})

V_53 = Vertex(name = 'V_53',
              particles = [ P.A, P.W__plus__, P.Pi0, P.Pi__minus__ ],
              color = [ '1' ],
              lorentz = [ L.VVSS1 ],
              couplings = {(0,0):C.GC_76})

V_54 = Vertex(name = 'V_54',
              particles = [ P.W__plus__, P.Pi0, P.Pi__minus__ ],
              color = [ '1' ],
              lorentz = [ L.VSS1 ],
              couplings = {(0,0):C.GC_65})

V_55 = Vertex(name = 'V_55',
              particles = [ P.W__plus__, P.Pi0, P.Pi0, P.Pi__minus__ ],
              color = [ '1' ],
              lorentz = [ L.VSSS3 ],
              couplings = {(0,0):C.GC_78})

V_56 = Vertex(name = 'V_56',
              particles = [ P.W__plus__, P.Pi__minus__, P.Pi__minus__, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.VSSS4 ],
              couplings = {(0,0):C.GC_77})

V_57 = Vertex(name = 'V_57',
              particles = [ P.p__tilde__, P.n, P.W__plus__ ],
              color = [ '1' ],
              lorentz = [ L.FFV1, L.FFV2 ],
              couplings = {(0,1):C.GC_111,(0,0):C.GC_69})

V_58 = Vertex(name = 'V_58',
              particles = [ P.n__tilde__, P.n, P.W__plus__, P.Pi__minus__ ],
              color = [ '1' ],
              lorentz = [ L.FFVS1, L.FFVS2 ],
              couplings = {(0,1):C.GC_113,(0,0):C.GC_80})

V_59 = Vertex(name = 'V_59',
              particles = [ P.p__tilde__, P.n, P.W__plus__, P.Pi0 ],
              color = [ '1' ],
              lorentz = [ L.FFVS1, L.FFVS2 ],
              couplings = {(0,1):C.GC_115,(0,0):C.GC_87})

V_60 = Vertex(name = 'V_60',
              particles = [ P.p__tilde__, P.p, P.W__plus__, P.Pi__minus__ ],
              color = [ '1' ],
              lorentz = [ L.FFVS1, L.FFVS2 ],
              couplings = {(0,1):C.GC_112,(0,0):C.GC_83})

V_61 = Vertex(name = 'V_61',
              particles = [ P.W__minus__, P.W__plus__, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.VVSS1 ],
              couplings = {(0,0):C.GC_64})

V_62 = Vertex(name = 'V_62',
              particles = [ P.W__minus__, P.W__plus__, P.H ],
              color = [ '1' ],
              lorentz = [ L.VVS1 ],
              couplings = {(0,0):C.GC_170})

V_63 = Vertex(name = 'V_63',
              particles = [ P.Delta0__tilde__, P.Delta0, P.W__plus__, P.Pi__minus__ ],
              color = [ '1' ],
              lorentz = [ L.RRVS1, L.RRVS3, L.RRVS5 ],
              couplings = {(0,1):C.GC_81,(0,2):C.GC_90,(0,0):C.GC_98})

V_64 = Vertex(name = 'V_64',
              particles = [ P.Delta0__tilde__, P.Delta__minus__, P.W__plus__ ],
              color = [ '1' ],
              lorentz = [ L.RRV1, L.RRV2, L.RRV3 ],
              couplings = {(0,1):C.GC_67,(0,2):C.GC_71,(0,0):C.GC_73})

V_65 = Vertex(name = 'V_65',
              particles = [ P.Delta0__tilde__, P.Delta__minus__, P.W__plus__, P.Pi0 ],
              color = [ '1' ],
              lorentz = [ L.RRVS1, L.RRVS3, L.RRVS5 ],
              couplings = {(0,1):C.GC_85,(0,2):C.GC_93,(0,0):C.GC_101})

V_66 = Vertex(name = 'V_66',
              particles = [ P.Delta__minus____tilde__, P.Delta__minus__, P.W__plus__, P.Pi__minus__ ],
              color = [ '1' ],
              lorentz = [ L.RRVS1, L.RRVS3, L.RRVS5 ],
              couplings = {(0,1):C.GC_79,(0,2):C.GC_89,(0,0):C.GC_97})

V_67 = Vertex(name = 'V_67',
              particles = [ P.Delta__plus____tilde__, P.Delta0, P.W__plus__ ],
              color = [ '1' ],
              lorentz = [ L.RRV1, L.RRV2, L.RRV3 ],
              couplings = {(0,1):C.GC_68,(0,2):C.GC_72,(0,0):C.GC_74})

V_68 = Vertex(name = 'V_68',
              particles = [ P.Delta__plus____tilde__, P.Delta0, P.W__plus__, P.Pi0 ],
              color = [ '1' ],
              lorentz = [ L.RRVS1, L.RRVS3, L.RRVS5 ],
              couplings = {(0,1):C.GC_87,(0,2):C.GC_95,(0,0):C.GC_103})

V_69 = Vertex(name = 'V_69',
              particles = [ P.Delta__plus____tilde__, P.Delta__plus__, P.W__plus__, P.Pi__minus__ ],
              color = [ '1' ],
              lorentz = [ L.RRVS1, L.RRVS3, L.RRVS5 ],
              couplings = {(0,1):C.GC_82,(0,2):C.GC_91,(0,0):C.GC_99})

V_70 = Vertex(name = 'V_70',
              particles = [ P.Delta__plus____plus____tilde__, P.Delta__plus__, P.W__plus__ ],
              color = [ '1' ],
              lorentz = [ L.RRV1, L.RRV2, L.RRV3 ],
              couplings = {(0,1):C.GC_67,(0,2):C.GC_71,(0,0):C.GC_73})

V_71 = Vertex(name = 'V_71',
              particles = [ P.Delta__plus____plus____tilde__, P.Delta__plus__, P.W__plus__, P.Pi0 ],
              color = [ '1' ],
              lorentz = [ L.RRVS1, L.RRVS3, L.RRVS5 ],
              couplings = {(0,1):C.GC_85,(0,2):C.GC_93,(0,0):C.GC_101})

V_72 = Vertex(name = 'V_72',
              particles = [ P.Delta__plus____plus____tilde__, P.Delta__plus____plus__, P.W__plus__, P.Pi__minus__ ],
              color = [ '1' ],
              lorentz = [ L.RRVS1, L.RRVS3, L.RRVS5 ],
              couplings = {(0,1):C.GC_84,(0,2):C.GC_92,(0,0):C.GC_100})

V_73 = Vertex(name = 'V_73',
              particles = [ P.A, P.Z, P.Pi__minus__, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.VVSS1 ],
              couplings = {(0,0):C.GC_145})

V_74 = Vertex(name = 'V_74',
              particles = [ P.Z, P.Pi0, P.Pi0, P.Pi0 ],
              color = [ '1' ],
              lorentz = [ L.VSSS5 ],
              couplings = {(0,0):C.GC_105})

V_75 = Vertex(name = 'V_75',
              particles = [ P.Z, P.Pi0, P.Pi__minus__, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.VSSS2 ],
              couplings = {(0,0):C.GC_106})

V_76 = Vertex(name = 'V_76',
              particles = [ P.Z, P.Pi__minus__, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.VSS1 ],
              couplings = {(0,0):C.GC_136})

V_77 = Vertex(name = 'V_77',
              particles = [ P.n__tilde__, P.n, P.Z ],
              color = [ '1' ],
              lorentz = [ L.FFV1, L.FFV2 ],
              couplings = {(0,1):C.GC_161,(0,0):C.GC_130})

V_78 = Vertex(name = 'V_78',
              particles = [ P.p__tilde__, P.p, P.Z ],
              color = [ '1' ],
              lorentz = [ L.FFV1, L.FFV2 ],
              couplings = {(0,1):C.GC_160,(0,0):C.GC_134})

V_79 = Vertex(name = 'V_79',
              particles = [ P.p__tilde__, P.n, P.Z, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.FFVS1, L.FFVS2 ],
              couplings = {(0,1):C.GC_163,(0,0):C.GC_149})

V_80 = Vertex(name = 'V_80',
              particles = [ P.n__tilde__, P.p, P.Z, P.Pi__minus__ ],
              color = [ '1' ],
              lorentz = [ L.FFVS1, L.FFVS2 ],
              couplings = {(0,1):C.GC_162,(0,0):C.GC_146})

V_81 = Vertex(name = 'V_81',
              particles = [ P.W__minus__, P.Z, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.VVS1 ],
              couplings = {(0,0):C.GC_43})

V_82 = Vertex(name = 'V_82',
              particles = [ P.W__minus__, P.Z, P.Pi0, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.VVSS1 ],
              couplings = {(0,0):C.GC_13})

V_83 = Vertex(name = 'V_83',
              particles = [ P.W__plus__, P.Z, P.Pi__minus__ ],
              color = [ '1' ],
              lorentz = [ L.VVS1 ],
              couplings = {(0,0):C.GC_42})

V_84 = Vertex(name = 'V_84',
              particles = [ P.W__plus__, P.Z, P.Pi0, P.Pi__minus__ ],
              color = [ '1' ],
              lorentz = [ L.VVSS1 ],
              couplings = {(0,0):C.GC_13})

V_85 = Vertex(name = 'V_85',
              particles = [ P.Z, P.Z, P.H, P.H ],
              color = [ '1' ],
              lorentz = [ L.VVSS1 ],
              couplings = {(0,0):C.GC_168})

V_86 = Vertex(name = 'V_86',
              particles = [ P.Z, P.Z, P.Pi__minus__, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.VVSS1 ],
              couplings = {(0,0):C.GC_11})

V_87 = Vertex(name = 'V_87',
              particles = [ P.Z, P.Z, P.H ],
              color = [ '1' ],
              lorentz = [ L.VVS1 ],
              couplings = {(0,0):C.GC_171})

V_88 = Vertex(name = 'V_88',
              particles = [ P.Delta0__tilde__, P.Delta0, P.Z ],
              color = [ '1' ],
              lorentz = [ L.RRV1, L.RRV2, L.RRV3 ],
              couplings = {(0,1):C.GC_129,(0,2):C.GC_137,(0,0):C.GC_141})

V_89 = Vertex(name = 'V_89',
              particles = [ P.Delta__minus____tilde__, P.Delta0, P.Z, P.Pi__minus__ ],
              color = [ '1' ],
              lorentz = [ L.RRVS1, L.RRVS3, L.RRVS5 ],
              couplings = {(0,0):C.GC_156,(0,1):C.GC_150,(0,2):C.GC_154})

V_90 = Vertex(name = 'V_90',
              particles = [ P.Delta0__tilde__, P.Delta__minus__, P.Z, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.RRVS1, L.RRVS3, L.RRVS5 ],
              couplings = {(0,0):C.GC_157,(0,1):C.GC_151,(0,2):C.GC_155})

V_91 = Vertex(name = 'V_91',
              particles = [ P.Delta__minus____tilde__, P.Delta__minus__, P.Z ],
              color = [ '1' ],
              lorentz = [ L.RRV1, L.RRV2, L.RRV3 ],
              couplings = {(0,1):C.GC_131,(0,2):C.GC_138,(0,0):C.GC_142})

V_92 = Vertex(name = 'V_92',
              particles = [ P.Delta__plus____tilde__, P.Delta0, P.Z, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.RRVS1, L.RRVS2, L.RRVS3, L.RRVS5 ],
              couplings = {(0,0):C.GC_159,(0,2):C.GC_148,(0,3):C.GC_153,(0,1):C.GC_108})

V_93 = Vertex(name = 'V_93',
              particles = [ P.Delta0__tilde__, P.Delta__plus__, P.Z, P.Pi__minus__ ],
              color = [ '1' ],
              lorentz = [ L.RRVS1, L.RRVS2, L.RRVS3, L.RRVS5 ],
              couplings = {(0,0):C.GC_158,(0,2):C.GC_147,(0,3):C.GC_152,(0,1):C.GC_107})

V_94 = Vertex(name = 'V_94',
              particles = [ P.Delta__plus____tilde__, P.Delta__plus__, P.Z ],
              color = [ '1' ],
              lorentz = [ L.RRV1, L.RRV2, L.RRV3 ],
              couplings = {(0,1):C.GC_132,(0,2):C.GC_139,(0,0):C.GC_143})

V_95 = Vertex(name = 'V_95',
              particles = [ P.Delta__plus____plus____tilde__, P.Delta__plus__, P.Z, P.Pi__plus__ ],
              color = [ '1' ],
              lorentz = [ L.RRVS1, L.RRVS3, L.RRVS4, L.RRVS5 ],
              couplings = {(0,0):C.GC_157,(0,2):C.GC_128,(0,1):C.GC_151,(0,3):C.GC_63})

V_96 = Vertex(name = 'V_96',
              particles = [ P.Delta__plus____tilde__, P.Delta__plus____plus__, P.Z, P.Pi__minus__ ],
              color = [ '1' ],
              lorentz = [ L.RRVS1, L.RRVS3, L.RRVS5 ],
              couplings = {(0,0):C.GC_156,(0,1):C.GC_150,(0,2):C.GC_154})

V_97 = Vertex(name = 'V_97',
              particles = [ P.Delta__plus____plus____tilde__, P.Delta__plus____plus__, P.Z ],
              color = [ '1' ],
              lorentz = [ L.RRV1, L.RRV2, L.RRV3 ],
              couplings = {(0,1):C.GC_135,(0,2):C.GC_140,(0,0):C.GC_144})

V_98 = Vertex(name = 'V_98',
              particles = [ P.e__plus__, P.e__minus__, P.A ],
              color = [ '1' ],
              lorentz = [ L.FFV1 ],
              couplings = {(0,0):C.GC_3})

V_99 = Vertex(name = 'V_99',
              particles = [ P.mu__plus__, P.mu__minus__, P.A ],
              color = [ '1' ],
              lorentz = [ L.FFV1 ],
              couplings = {(0,0):C.GC_3})

V_100 = Vertex(name = 'V_100',
               particles = [ P.ta__plus__, P.ta__minus__, P.A ],
               color = [ '1' ],
               lorentz = [ L.FFV1 ],
               couplings = {(0,0):C.GC_3})

V_101 = Vertex(name = 'V_101',
               particles = [ P.e__plus__, P.ve, P.W__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FFV3 ],
               couplings = {(0,0):C.GC_70})

V_102 = Vertex(name = 'V_102',
               particles = [ P.mu__plus__, P.vm, P.W__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FFV3 ],
               couplings = {(0,0):C.GC_70})

V_103 = Vertex(name = 'V_103',
               particles = [ P.ta__plus__, P.vt, P.W__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FFV3 ],
               couplings = {(0,0):C.GC_70})

V_104 = Vertex(name = 'V_104',
               particles = [ P.ve__tilde__, P.e__minus__, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FFV3 ],
               couplings = {(0,0):C.GC_70})

V_105 = Vertex(name = 'V_105',
               particles = [ P.vm__tilde__, P.mu__minus__, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FFV3 ],
               couplings = {(0,0):C.GC_70})

V_106 = Vertex(name = 'V_106',
               particles = [ P.vt__tilde__, P.ta__minus__, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FFV3 ],
               couplings = {(0,0):C.GC_70})

V_107 = Vertex(name = 'V_107',
               particles = [ P.ve__tilde__, P.ve, P.Z ],
               color = [ '1' ],
               lorentz = [ L.FFV3 ],
               couplings = {(0,0):C.GC_133})

V_108 = Vertex(name = 'V_108',
               particles = [ P.vm__tilde__, P.vm, P.Z ],
               color = [ '1' ],
               lorentz = [ L.FFV3 ],
               couplings = {(0,0):C.GC_133})

V_109 = Vertex(name = 'V_109',
               particles = [ P.vt__tilde__, P.vt, P.Z ],
               color = [ '1' ],
               lorentz = [ L.FFV3 ],
               couplings = {(0,0):C.GC_133})

V_110 = Vertex(name = 'V_110',
               particles = [ P.e__plus__, P.e__minus__, P.Z ],
               color = [ '1' ],
               lorentz = [ L.FFV3, L.FFV4 ],
               couplings = {(0,0):C.GC_75,(0,1):C.GC_127})

V_111 = Vertex(name = 'V_111',
               particles = [ P.mu__plus__, P.mu__minus__, P.Z ],
               color = [ '1' ],
               lorentz = [ L.FFV3, L.FFV4 ],
               couplings = {(0,0):C.GC_75,(0,1):C.GC_127})

V_112 = Vertex(name = 'V_112',
               particles = [ P.ta__plus__, P.ta__minus__, P.Z ],
               color = [ '1' ],
               lorentz = [ L.FFV3, L.FFV4 ],
               couplings = {(0,0):C.GC_75,(0,1):C.GC_127})

V_113 = Vertex(name = 'V_113',
               particles = [ P.n__tilde__, P.n, P.Pi0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_45})

V_114 = Vertex(name = 'V_114',
               particles = [ P.p__tilde__, P.n, P.A, P.Pi__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FFVS2 ],
               couplings = {(0,0):C.GC_47})

V_115 = Vertex(name = 'V_115',
               particles = [ P.p__tilde__, P.n, P.Pi__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_46})

V_116 = Vertex(name = 'V_116',
               particles = [ P.n__tilde__, P.p, P.A, P.Pi__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FFVS2 ],
               couplings = {(0,0):C.GC_48})

V_117 = Vertex(name = 'V_117',
               particles = [ P.n__tilde__, P.p, P.Pi__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_46})

V_118 = Vertex(name = 'V_118',
               particles = [ P.p__tilde__, P.p, P.Pi0 ],
               color = [ '1' ],
               lorentz = [ L.FFS1 ],
               couplings = {(0,0):C.GC_44})

V_119 = Vertex(name = 'V_119',
               particles = [ P.Delta0__tilde__, P.n, P.Pi0 ],
               color = [ '1' ],
               lorentz = [ L.RFS1 ],
               couplings = {(0,0):C.GC_56})

V_120 = Vertex(name = 'V_120',
               particles = [ P.Delta0__tilde__, P.n, P.W__minus__, P.Pi__plus__ ],
               color = [ '1' ],
               lorentz = [ L.RFVS1 ],
               couplings = {(0,0):C.GC_125})

V_121 = Vertex(name = 'V_121',
               particles = [ P.Delta0__tilde__, P.n, P.W__plus__, P.Pi__minus__ ],
               color = [ '1' ],
               lorentz = [ L.RFVS1 ],
               couplings = {(0,0):C.GC_126})

V_122 = Vertex(name = 'V_122',
               particles = [ P.Delta0__tilde__, P.n, P.Z ],
               color = [ '1' ],
               lorentz = [ L.RFV1 ],
               couplings = {(0,0):C.GC_120})

V_123 = Vertex(name = 'V_123',
               particles = [ P.Delta__plus____tilde__, P.p, P.Pi0 ],
               color = [ '1' ],
               lorentz = [ L.RFS1 ],
               couplings = {(0,0):C.GC_56})

V_124 = Vertex(name = 'V_124',
               particles = [ P.Delta__plus____tilde__, P.p, P.W__minus__, P.Pi__plus__ ],
               color = [ '1' ],
               lorentz = [ L.RFVS1 ],
               couplings = {(0,0):C.GC_125})

V_125 = Vertex(name = 'V_125',
               particles = [ P.Delta__plus____tilde__, P.p, P.W__plus__, P.Pi__minus__ ],
               color = [ '1' ],
               lorentz = [ L.RFVS1 ],
               couplings = {(0,0):C.GC_126})

V_126 = Vertex(name = 'V_126',
               particles = [ P.Delta__plus____tilde__, P.p, P.Z ],
               color = [ '1' ],
               lorentz = [ L.RFV1 ],
               couplings = {(0,0):C.GC_120})

V_127 = Vertex(name = 'V_127',
               particles = [ P.Delta__minus____tilde__, P.n, P.A, P.Pi__minus__ ],
               color = [ '1' ],
               lorentz = [ L.RFVS1 ],
               couplings = {(0,0):C.GC_59})

V_128 = Vertex(name = 'V_128',
               particles = [ P.Delta__minus____tilde__, P.n, P.Pi__minus__ ],
               color = [ '1' ],
               lorentz = [ L.RFS1 ],
               couplings = {(0,0):C.GC_55})

V_129 = Vertex(name = 'V_129',
               particles = [ P.Delta__plus____tilde__, P.n, P.A, P.Pi__plus__ ],
               color = [ '1' ],
               lorentz = [ L.RFVS1 ],
               couplings = {(0,0):C.GC_61})

V_130 = Vertex(name = 'V_130',
               particles = [ P.Delta__plus____tilde__, P.n, P.Pi__plus__ ],
               color = [ '1' ],
               lorentz = [ L.RFS1 ],
               couplings = {(0,0):C.GC_57})

V_131 = Vertex(name = 'V_131',
               particles = [ P.Delta__minus____tilde__, P.n, P.W__minus__ ],
               color = [ '1' ],
               lorentz = [ L.RFV1 ],
               couplings = {(0,0):C.GC_117})

V_132 = Vertex(name = 'V_132',
               particles = [ P.Delta__minus____tilde__, P.n, P.W__minus__, P.Pi0 ],
               color = [ '1' ],
               lorentz = [ L.RFVS1 ],
               couplings = {(0,0):C.GC_122})

V_133 = Vertex(name = 'V_133',
               particles = [ P.Delta__plus____tilde__, P.n, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.RFV1 ],
               couplings = {(0,0):C.GC_118})

V_134 = Vertex(name = 'V_134',
               particles = [ P.Delta__plus____tilde__, P.n, P.W__plus__, P.Pi0 ],
               color = [ '1' ],
               lorentz = [ L.RFVS1 ],
               couplings = {(0,0):C.GC_124})

V_135 = Vertex(name = 'V_135',
               particles = [ P.Delta__minus____tilde__, P.n, P.Z, P.Pi__minus__ ],
               color = [ '1' ],
               lorentz = [ L.RFVS1 ],
               couplings = {(0,0):C.GC_165})

V_136 = Vertex(name = 'V_136',
               particles = [ P.Delta__plus____tilde__, P.n, P.Z, P.Pi__plus__ ],
               color = [ '1' ],
               lorentz = [ L.RFVS1 ],
               couplings = {(0,0):C.GC_167})

V_137 = Vertex(name = 'V_137',
               particles = [ P.Delta0__tilde__, P.p, P.A, P.Pi__minus__ ],
               color = [ '1' ],
               lorentz = [ L.RFVS1 ],
               couplings = {(0,0):C.GC_61})

V_138 = Vertex(name = 'V_138',
               particles = [ P.Delta0__tilde__, P.p, P.Pi__minus__ ],
               color = [ '1' ],
               lorentz = [ L.RFS1 ],
               couplings = {(0,0):C.GC_58})

V_139 = Vertex(name = 'V_139',
               particles = [ P.Delta__plus____plus____tilde__, P.p, P.A, P.Pi__plus__ ],
               color = [ '1' ],
               lorentz = [ L.RFVS1 ],
               couplings = {(0,0):C.GC_59})

V_140 = Vertex(name = 'V_140',
               particles = [ P.Delta__plus____plus____tilde__, P.p, P.Pi__plus__ ],
               color = [ '1' ],
               lorentz = [ L.RFS1 ],
               couplings = {(0,0):C.GC_54})

V_141 = Vertex(name = 'V_141',
               particles = [ P.Delta0__tilde__, P.p, P.W__minus__ ],
               color = [ '1' ],
               lorentz = [ L.RFV1 ],
               couplings = {(0,0):C.GC_119})

V_142 = Vertex(name = 'V_142',
               particles = [ P.Delta0__tilde__, P.p, P.W__minus__, P.Pi0 ],
               color = [ '1' ],
               lorentz = [ L.RFVS1 ],
               couplings = {(0,0):C.GC_124})

V_143 = Vertex(name = 'V_143',
               particles = [ P.Delta__plus____plus____tilde__, P.p, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.RFV1 ],
               couplings = {(0,0):C.GC_116})

V_144 = Vertex(name = 'V_144',
               particles = [ P.Delta__plus____plus____tilde__, P.p, P.W__plus__, P.Pi0 ],
               color = [ '1' ],
               lorentz = [ L.RFVS1 ],
               couplings = {(0,0):C.GC_122})

V_145 = Vertex(name = 'V_145',
               particles = [ P.Delta0__tilde__, P.p, P.Z, P.Pi__minus__ ],
               color = [ '1' ],
               lorentz = [ L.RFVS1 ],
               couplings = {(0,0):C.GC_167})

V_146 = Vertex(name = 'V_146',
               particles = [ P.Delta__plus____plus____tilde__, P.p, P.Z, P.Pi__plus__ ],
               color = [ '1' ],
               lorentz = [ L.RFVS1 ],
               couplings = {(0,0):C.GC_165})

V_147 = Vertex(name = 'V_147',
               particles = [ P.n__tilde__, P.Delta0, P.Pi0 ],
               color = [ '1' ],
               lorentz = [ L.FRS1 ],
               couplings = {(0,0):C.GC_56})

V_148 = Vertex(name = 'V_148',
               particles = [ P.n__tilde__, P.Delta__minus__, P.A, P.Pi__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FRVS1 ],
               couplings = {(0,0):C.GC_60})

V_149 = Vertex(name = 'V_149',
               particles = [ P.n__tilde__, P.Delta__minus__, P.Pi__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FRS1 ],
               couplings = {(0,0):C.GC_55})

V_150 = Vertex(name = 'V_150',
               particles = [ P.n__tilde__, P.Delta__plus__, P.A, P.Pi__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FRVS1 ],
               couplings = {(0,0):C.GC_62})

V_151 = Vertex(name = 'V_151',
               particles = [ P.n__tilde__, P.Delta__plus__, P.Pi__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FRS1 ],
               couplings = {(0,0):C.GC_57})

V_152 = Vertex(name = 'V_152',
               particles = [ P.p__tilde__, P.Delta0, P.A, P.Pi__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FRVS1 ],
               couplings = {(0,0):C.GC_62})

V_153 = Vertex(name = 'V_153',
               particles = [ P.p__tilde__, P.Delta0, P.Pi__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FRS1 ],
               couplings = {(0,0):C.GC_58})

V_154 = Vertex(name = 'V_154',
               particles = [ P.p__tilde__, P.Delta__plus__, P.Pi0 ],
               color = [ '1' ],
               lorentz = [ L.FRS1 ],
               couplings = {(0,0):C.GC_56})

V_155 = Vertex(name = 'V_155',
               particles = [ P.p__tilde__, P.Delta__plus____plus__, P.A, P.Pi__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FRVS1 ],
               couplings = {(0,0):C.GC_60})

V_156 = Vertex(name = 'V_156',
               particles = [ P.p__tilde__, P.Delta__plus____plus__, P.Pi__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FRS1 ],
               couplings = {(0,0):C.GC_54})

V_157 = Vertex(name = 'V_157',
               particles = [ P.n__tilde__, P.Delta0, P.W__minus__, P.Pi__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FRVS1 ],
               couplings = {(0,0):C.GC_125})

V_158 = Vertex(name = 'V_158',
               particles = [ P.n__tilde__, P.Delta__plus__, P.W__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FRV1 ],
               couplings = {(0,0):C.GC_118})

V_159 = Vertex(name = 'V_159',
               particles = [ P.n__tilde__, P.Delta__plus__, P.W__minus__, P.Pi0 ],
               color = [ '1' ],
               lorentz = [ L.FRVS1 ],
               couplings = {(0,0):C.GC_123})

V_160 = Vertex(name = 'V_160',
               particles = [ P.p__tilde__, P.Delta__plus__, P.W__minus__, P.Pi__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FRVS1 ],
               couplings = {(0,0):C.GC_125})

V_161 = Vertex(name = 'V_161',
               particles = [ P.p__tilde__, P.Delta__plus____plus__, P.W__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FRV1 ],
               couplings = {(0,0):C.GC_116})

V_162 = Vertex(name = 'V_162',
               particles = [ P.p__tilde__, P.Delta__plus____plus__, P.W__minus__, P.Pi0 ],
               color = [ '1' ],
               lorentz = [ L.FRVS1 ],
               couplings = {(0,0):C.GC_121})

V_163 = Vertex(name = 'V_163',
               particles = [ P.n__tilde__, P.Delta0, P.W__plus__, P.Pi__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FRVS1 ],
               couplings = {(0,0):C.GC_126})

V_164 = Vertex(name = 'V_164',
               particles = [ P.n__tilde__, P.Delta__minus__, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FRV1 ],
               couplings = {(0,0):C.GC_117})

V_165 = Vertex(name = 'V_165',
               particles = [ P.n__tilde__, P.Delta__minus__, P.W__plus__, P.Pi0 ],
               color = [ '1' ],
               lorentz = [ L.FRVS1 ],
               couplings = {(0,0):C.GC_121})

V_166 = Vertex(name = 'V_166',
               particles = [ P.p__tilde__, P.Delta0, P.W__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FRV1 ],
               couplings = {(0,0):C.GC_119})

V_167 = Vertex(name = 'V_167',
               particles = [ P.p__tilde__, P.Delta0, P.W__plus__, P.Pi0 ],
               color = [ '1' ],
               lorentz = [ L.FRVS1 ],
               couplings = {(0,0):C.GC_123})

V_168 = Vertex(name = 'V_168',
               particles = [ P.p__tilde__, P.Delta__plus__, P.W__plus__, P.Pi__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FRVS1 ],
               couplings = {(0,0):C.GC_126})

V_169 = Vertex(name = 'V_169',
               particles = [ P.n__tilde__, P.Delta0, P.Z ],
               color = [ '1' ],
               lorentz = [ L.FRV1 ],
               couplings = {(0,0):C.GC_120})

V_170 = Vertex(name = 'V_170',
               particles = [ P.n__tilde__, P.Delta__minus__, P.Z, P.Pi__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FRVS1 ],
               couplings = {(0,0):C.GC_164})

V_171 = Vertex(name = 'V_171',
               particles = [ P.n__tilde__, P.Delta__plus__, P.Z, P.Pi__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FRVS1 ],
               couplings = {(0,0):C.GC_166})

V_172 = Vertex(name = 'V_172',
               particles = [ P.p__tilde__, P.Delta0, P.Z, P.Pi__plus__ ],
               color = [ '1' ],
               lorentz = [ L.FRVS1 ],
               couplings = {(0,0):C.GC_166})

V_173 = Vertex(name = 'V_173',
               particles = [ P.p__tilde__, P.Delta__plus__, P.Z ],
               color = [ '1' ],
               lorentz = [ L.FRV1 ],
               couplings = {(0,0):C.GC_120})

V_174 = Vertex(name = 'V_174',
               particles = [ P.p__tilde__, P.Delta__plus____plus__, P.Z, P.Pi__minus__ ],
               color = [ '1' ],
               lorentz = [ L.FRVS1 ],
               couplings = {(0,0):C.GC_164})

