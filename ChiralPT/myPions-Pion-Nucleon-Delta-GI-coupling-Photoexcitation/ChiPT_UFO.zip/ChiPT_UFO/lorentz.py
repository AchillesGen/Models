# This file was automatically created by FeynRules 2.3.49
# Mathematica version: 14.3.0 for Linux x86 (64-bit) (July 8, 2025)
# Date: Mon 3 Aug 2026 11:03:21


from __future__ import absolute_import
from .object_library import all_lorentz, Lorentz

from .function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot
try:
   from . import form_factors as ForFac 
except ImportError:
   pass


SSS1 = Lorentz(name = 'SSS1',
               spins = [ 1, 1, 1 ],
               structure = '1')

FFS1 = Lorentz(name = 'FFS1',
               spins = [ 2, 2, 1 ],
               structure = 'P(-1,3)*Gamma5(-2,1)*Gamma(-1,2,-2)')

FFS2 = Lorentz(name = 'FFS2',
               spins = [ 2, 2, 1 ],
               structure = 'ProjM(2,1) + ProjP(2,1)')

FFV1 = Lorentz(name = 'FFV1',
               spins = [ 2, 2, 3 ],
               structure = 'Gamma(3,2,1)')

FFV2 = Lorentz(name = 'FFV2',
               spins = [ 2, 2, 3 ],
               structure = 'Gamma5(-1,1)*Gamma(3,2,-1)')

FFV3 = Lorentz(name = 'FFV3',
               spins = [ 2, 2, 3 ],
               structure = 'Gamma(3,2,-1)*ProjM(-1,1)')

FFV4 = Lorentz(name = 'FFV4',
               spins = [ 2, 2, 3 ],
               structure = 'Gamma(3,2,-1)*ProjM(-1,1) + 2*Gamma(3,2,-1)*ProjP(-1,1)')

FRS1 = Lorentz(name = 'FRS1',
               spins = [ 2, 4, 1 ],
               structure = '-(Epsilon(2,-1,-2,-3)*P(-2,2)*P(-1,3)*Gamma5(-4,1)*Gamma(-3,2,-4))')

FRV1 = Lorentz(name = 'FRV1',
               spins = [ 2, 4, 3 ],
               structure = '-(Epsilon(2,3,-1,-2)*P(-1,2)*Gamma5(-3,1)*Gamma(-2,2,-3))')

FRV2 = Lorentz(name = 'FRV2',
               spins = [ 2, 4, 3 ],
               structure = '-2*Epsilon(2,3,-1,-2)*P(-2,3)*P(-1,2)*Identity(2,1)')

FRV3 = Lorentz(name = 'FRV3',
               spins = [ 2, 4, 3 ],
               structure = 'P(2,3)*P(3,2)*Gamma5(2,1) - P(-1,2)*P(-1,3)*Gamma5(2,1)*Metric(2,3)')

VSS1 = Lorentz(name = 'VSS1',
               spins = [ 3, 1, 1 ],
               structure = 'P(1,2) - P(1,3)')

VVS1 = Lorentz(name = 'VVS1',
               spins = [ 3, 3, 1 ],
               structure = 'Metric(1,2)')

RFS1 = Lorentz(name = 'RFS1',
               spins = [ 4, 2, 1 ],
               structure = '-(Epsilon(1,-1,-2,-3)*P(-2,1)*P(-1,3)*Gamma5(-4,1)*Gamma(-3,2,-4))')

RFV1 = Lorentz(name = 'RFV1',
               spins = [ 4, 2, 3 ],
               structure = '-(Epsilon(1,3,-1,-2)*P(-1,1)*Gamma5(-3,1)*Gamma(-2,2,-3))')

RFV2 = Lorentz(name = 'RFV2',
               spins = [ 4, 2, 3 ],
               structure = '-2*Epsilon(1,3,-1,-2)*P(-2,3)*P(-1,1)*Identity(2,1)')

RFV3 = Lorentz(name = 'RFV3',
               spins = [ 4, 2, 3 ],
               structure = 'P(1,3)*P(3,1)*Gamma5(2,1) - P(-1,1)*P(-1,3)*Gamma5(2,1)*Metric(1,3)')

RRV1 = Lorentz(name = 'RRV1',
               spins = [ 4, 4, 3 ],
               structure = 'Gamma(1,-1,1)*Gamma(2,2,-2)*Gamma(3,-2,-1)')

RRV2 = Lorentz(name = 'RRV2',
               spins = [ 4, 4, 3 ],
               structure = 'Gamma(1,-1,1)*Gamma(2,2,-2)*Gamma(3,-2,-1) + 2*Gamma(3,2,1)*Metric(1,2)')

RRV3 = Lorentz(name = 'RRV3',
               spins = [ 4, 4, 3 ],
               structure = 'Gamma(1,-1,1)*Gamma(2,2,-2)*Gamma(3,-2,-1) + Gamma(2,2,1)*Metric(1,3) + Gamma(1,2,1)*Metric(2,3)')

SSSS1 = Lorentz(name = 'SSSS1',
                spins = [ 1, 1, 1, 1 ],
                structure = '1')

SSSS2 = Lorentz(name = 'SSSS2',
                spins = [ 1, 1, 1, 1 ],
                structure = 'P(-1,1)*P(-1,3) + P(-1,2)*P(-1,3) + P(-1,1)*P(-1,4) + P(-1,2)*P(-1,4)')

SSSS3 = Lorentz(name = 'SSSS3',
                spins = [ 1, 1, 1, 1 ],
                structure = 'P(-1,1)*P(-1,2) + (P(-1,1)*P(-1,3))/2. + (P(-1,2)*P(-1,3))/2. + (P(-1,1)*P(-1,4))/2. + (P(-1,2)*P(-1,4))/2. + P(-1,3)*P(-1,4)')

SSSS4 = Lorentz(name = 'SSSS4',
                spins = [ 1, 1, 1, 1 ],
                structure = 'P(-1,1)*P(-1,2) + P(-1,1)*P(-1,3) + P(-1,2)*P(-1,3) + P(-1,1)*P(-1,4) + P(-1,2)*P(-1,4) + P(-1,3)*P(-1,4)')

FFSS1 = Lorentz(name = 'FFSS1',
                spins = [ 2, 2, 1, 1 ],
                structure = 'P(-1,3)*Gamma(-1,2,1) - P(-1,4)*Gamma(-1,2,1)')

FFVS1 = Lorentz(name = 'FFVS1',
                spins = [ 2, 2, 3, 1 ],
                structure = 'Gamma(3,2,1)')

FFVS2 = Lorentz(name = 'FFVS2',
                spins = [ 2, 2, 3, 1 ],
                structure = 'Gamma5(-1,1)*Gamma(3,2,-1)')

FRVS1 = Lorentz(name = 'FRVS1',
                spins = [ 2, 4, 3, 1 ],
                structure = '-(Epsilon(2,3,-1,-2)*P(-1,2)*Gamma5(-3,1)*Gamma(-2,2,-3))')

VSSS1 = Lorentz(name = 'VSSS1',
                spins = [ 3, 1, 1, 1 ],
                structure = 'P(1,2)')

VSSS2 = Lorentz(name = 'VSSS2',
                spins = [ 3, 1, 1, 1 ],
                structure = 'P(1,2) - P(1,3) - P(1,4)')

VSSS3 = Lorentz(name = 'VSSS3',
                spins = [ 3, 1, 1, 1 ],
                structure = 'P(1,2) + P(1,3) - P(1,4)')

VSSS4 = Lorentz(name = 'VSSS4',
                spins = [ 3, 1, 1, 1 ],
                structure = 'P(1,4)')

VSSS5 = Lorentz(name = 'VSSS5',
                spins = [ 3, 1, 1, 1 ],
                structure = 'P(1,2) + P(1,3) + P(1,4)')

VVSS1 = Lorentz(name = 'VVSS1',
                spins = [ 3, 3, 1, 1 ],
                structure = 'Metric(1,2)')

RFVS1 = Lorentz(name = 'RFVS1',
                spins = [ 4, 2, 3, 1 ],
                structure = '-(Epsilon(1,3,-1,-2)*P(-1,1)*Gamma5(-3,1)*Gamma(-2,2,-3))')

RRSS1 = Lorentz(name = 'RRSS1',
                spins = [ 4, 4, 1, 1 ],
                structure = 'P(-1,3)*Gamma(-1,-3,-2)*Gamma(1,-2,1)*Gamma(2,2,-3) - P(-1,4)*Gamma(-1,-3,-2)*Gamma(1,-2,1)*Gamma(2,2,-3)')

RRSS2 = Lorentz(name = 'RRSS2',
                spins = [ 4, 4, 1, 1 ],
                structure = 'P(2,3)*Gamma(1,2,1) - P(2,4)*Gamma(1,2,1) + P(-1,3)*Gamma(-1,-3,-2)*Gamma(1,-2,1)*Gamma(2,2,-3) - P(-1,4)*Gamma(-1,-3,-2)*Gamma(1,-2,1)*Gamma(2,2,-3) + P(1,3)*Gamma(2,2,1) - P(1,4)*Gamma(2,2,1)')

RRSS3 = Lorentz(name = 'RRSS3',
                spins = [ 4, 4, 1, 1 ],
                structure = 'P(-1,3)*Gamma(-1,-3,-2)*Gamma(1,-2,1)*Gamma(2,2,-3) - P(-1,4)*Gamma(-1,-3,-2)*Gamma(1,-2,1)*Gamma(2,2,-3) + 2*P(-1,3)*Gamma(-1,2,1)*Metric(1,2) - 2*P(-1,4)*Gamma(-1,2,1)*Metric(1,2)')

RRVS1 = Lorentz(name = 'RRVS1',
                spins = [ 4, 4, 3, 1 ],
                structure = 'Gamma(1,-1,1)*Gamma(2,2,-2)*Gamma(3,-2,-1)')

RRVS2 = Lorentz(name = 'RRVS2',
                spins = [ 4, 4, 3, 1 ],
                structure = 'Gamma(3,2,1)*Metric(1,2)')

RRVS3 = Lorentz(name = 'RRVS3',
                spins = [ 4, 4, 3, 1 ],
                structure = 'Gamma(1,-1,1)*Gamma(2,2,-2)*Gamma(3,-2,-1) + 2*Gamma(3,2,1)*Metric(1,2)')

RRVS4 = Lorentz(name = 'RRVS4',
                spins = [ 4, 4, 3, 1 ],
                structure = 'Gamma(1,-2,1)*Gamma(2,2,-1)*Gamma(3,-1,-2) + Gamma(2,2,1)*Metric(1,3) + Gamma(1,2,1)*Metric(2,3)')

RRVS5 = Lorentz(name = 'RRVS5',
                spins = [ 4, 4, 3, 1 ],
                structure = 'Gamma(1,-1,1)*Gamma(2,2,-2)*Gamma(3,-2,-1) + Gamma(2,2,1)*Metric(1,3) + Gamma(1,2,1)*Metric(2,3)')

