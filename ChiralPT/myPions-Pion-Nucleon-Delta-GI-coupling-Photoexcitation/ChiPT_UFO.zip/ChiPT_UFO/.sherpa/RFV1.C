#include "METOOLS/Explicit/Lorentz_Calculator.H"
#include "METOOLS/Currents/C_Scalar.H"
#include "METOOLS/Currents/C_Spinor.H"
#include "METOOLS/Currents/C_Vector.H"
#include "METOOLS/Currents/C_RaritaSchwinger.H"
#include "METOOLS/Explicit/Vertex.H"
#include "METOOLS/Explicit/Form_Factor.H"
#include "MODEL/Main/Single_Vertex.H"
#include "ATOOLS/Org/Message.H"
#include "ATOOLS/Org/Exception.H"
#include "ATOOLS/Math/MyComplex.H"

namespace METOOLS {

  template <typename SType>
  class RFV1_Calculator: public Lorentz_Calculator {
  public:

    typedef std::complex<SType> SComplex;

    const SComplex I = SComplex(0.0,1.0);
    
    RFV1_Calculator(const Vertex_Key &key):
      Lorentz_Calculator(key) {

    }

    std::string Label() const { return "RFV1"; }

    CObject *Evaluate(const CObject_Vector &jj)
    {
// if outgoing index is 0
if (p_v->V()->id.back()==0) {
const CSpinor<SType> & j1 = ((jj[0]->Get<CSpinor<SType>>())->B() == -1 ? (*(jj[0]->Get<CSpinor<SType>>())) : (*(jj[0]->Get<CSpinor<SType>>())).CConj());
const SComplex & j10 = j1[0];
const SComplex & j11 = j1[1];
const SComplex & j12 = j1[2];
const SComplex & j13 = j1[3];
const ATOOLS::Vec4D & p1 = p_v->J(0)->P();
const double& p10 = p1[0];
const double& p11 = p1[ATOOLS::Spinor<SType>::R1()];
const double& p12 = p1[ATOOLS::Spinor<SType>::R2()];
const double& p13 = p1[ATOOLS::Spinor<SType>::R3()];
const CVec4<SType> & j2 = *(jj[1]->Get<CVec4<SType>>());
const SComplex & j20 = j2[0];
const SComplex & j21 = j2[ATOOLS::Spinor<SType>::R1()];
const SComplex & j22 = j2[ATOOLS::Spinor<SType>::R2()];
const SComplex & j23 = j2[ATOOLS::Spinor<SType>::R3()];
const ATOOLS::Vec4D & p2 = p_v->J(1)->P();
const double& p20 = p2[0];
const double& p21 = p2[ATOOLS::Spinor<SType>::R1()];
const double& p22 = p2[ATOOLS::Spinor<SType>::R2()];
const double& p23 = p2[ATOOLS::Spinor<SType>::R3()];
CRaritaSchwinger<SType>* j0 = nullptr;
ATOOLS::Vec4D p0 = -p1-p2;
const double& p00 = p0[0];
const double& p01 = p0[ATOOLS::Spinor<SType>::R1()];
const double& p02 = p0[ATOOLS::Spinor<SType>::R2()];
const double& p03 = p0[ATOOLS::Spinor<SType>::R3()];
j0 = CRaritaSchwinger<SType>::New(m_r[0],-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
(*j0)[0*4+0] = 1.0*p01*j12*j22 - 1.0*p02*j12*j21 + 1.0*I*p03*j13*j21 - 1.0*p03*j13*j22 - 1.0*j13*j23*(1.0*I*p01 - 1.0*p02);
(*j0)[0*4+1] = -1.0*p01*j13*j22 + 1.0*p02*j13*j21 - 1.0*I*p03*j12*j21 - 1.0*p03*j12*j22 - 1.0*j12*j23*(-1.0*I*p01 - 1.0*p02);
(*j0)[0*4+2] = 1.0*p01*j10*j22 - 1.0*p02*j10*j21 + 1.0*I*p03*j11*j21 - 1.0*p03*j11*j22 - 1.0*j11*j23*(1.0*I*p01 - 1.0*p02);
(*j0)[0*4+3] = -1.0*p01*j11*j22 + 1.0*p02*j11*j21 - 1.0*I*p03*j10*j21 - 1.0*p03*j10*j22 - 1.0*j10*j23*(-1.0*I*p01 - 1.0*p02);
(*j0)[ATOOLS::Spinor<SType>::R1()*4+0] = -1.0*I*p00*j13*j23 - 1.0*p02*j12*j20 - 1.0*p02*j12*j23 + 1.0*I*p03*j13*j20 - 1.0*j12*j22*(-1.0*p00 - 1.0*p03);
(*j0)[ATOOLS::Spinor<SType>::R1()*4+1] = 1.0*I*p00*j12*j23 + 1.0*p02*j13*j20 - 1.0*p02*j13*j23 - 1.0*I*p03*j12*j20 - 1.0*j13*j22*(1.0*p00 - 1.0*p03);
(*j0)[ATOOLS::Spinor<SType>::R1()*4+2] = -1.0*I*p00*j11*j23 - 1.0*p02*j10*j20 + 1.0*p02*j10*j23 + 1.0*I*p03*j11*j20 - 1.0*j10*j22*(-1.0*p00 + 1.0*p03);
(*j0)[ATOOLS::Spinor<SType>::R1()*4+3] = 1.0*I*p00*j10*j23 + 1.0*p02*j11*j20 + 1.0*p02*j11*j23 - 1.0*I*p03*j10*j20 - 1.0*j11*j22*(1.0*p00 + 1.0*p03);
(*j0)[ATOOLS::Spinor<SType>::R2()*4+0] = 1.0*p00*j13*j23 + 1.0*p01*j12*j20 + 1.0*p01*j12*j23 - 1.0*p03*j13*j20 - 1.0*j12*j21*(1.0*p00 + 1.0*p03);
(*j0)[ATOOLS::Spinor<SType>::R2()*4+1] = 1.0*p00*j12*j23 - 1.0*p01*j13*j20 + 1.0*p01*j13*j23 - 1.0*p03*j12*j20 - 1.0*j13*j21*(-1.0*p00 + 1.0*p03);
(*j0)[ATOOLS::Spinor<SType>::R2()*4+2] = 1.0*p00*j11*j23 + 1.0*p01*j10*j20 - 1.0*p01*j10*j23 - 1.0*p03*j11*j20 - 1.0*j10*j21*(1.0*p00 - 1.0*p03);
(*j0)[ATOOLS::Spinor<SType>::R2()*4+3] = 1.0*p00*j10*j23 - 1.0*p01*j11*j20 - 1.0*p01*j11*j23 - 1.0*p03*j10*j20 - 1.0*j11*j21*(-1.0*p00 - 1.0*p03);
(*j0)[ATOOLS::Spinor<SType>::R3()*4+0] = 1.0*I*p00*j13*j21 - 1.0*p00*j13*j22 - 1.0*p01*j12*j22 + 1.0*p02*j12*j21 + 1.0*j13*j20*(-1.0*I*p01 + 1.0*p02);
(*j0)[ATOOLS::Spinor<SType>::R3()*4+1] = -1.0*I*p00*j12*j21 - 1.0*p00*j12*j22 - 1.0*p01*j13*j22 + 1.0*p02*j13*j21 + 1.0*j12*j20*(1.0*I*p01 + 1.0*p02);
(*j0)[ATOOLS::Spinor<SType>::R3()*4+2] = 1.0*I*p00*j11*j21 - 1.0*p00*j11*j22 + 1.0*p01*j10*j22 - 1.0*p02*j10*j21 + 1.0*j11*j20*(-1.0*I*p01 + 1.0*p02);
(*j0)[ATOOLS::Spinor<SType>::R3()*4+3] = -1.0*I*p00*j10*j21 - 1.0*p00*j10*j22 + 1.0*p01*j11*j22 - 1.0*p02*j11*j21 + 1.0*j10*j20*(1.0*I*p01 + 1.0*p02);
j0->SetS(j1.S()|j2.S());
return j0;
}
// if outgoing index is 1
if (p_v->V()->id.back()==1) {
const CRaritaSchwinger<SType> & j0 = ((jj[1]->Get<CRaritaSchwinger<SType>>())->B() == 1 ? (*(jj[1]->Get<CRaritaSchwinger<SType>>())) : (*(jj[1]->Get<CRaritaSchwinger<SType>>())).CConj());
const SComplex & j00 = j0[4*0+0];
const SComplex & j01 = j0[4*0+1];
const SComplex & j02 = j0[4*0+2];
const SComplex & j03 = j0[4*0+3];
const SComplex & j04 = j0[4*ATOOLS::Spinor<SType>::R1()+0];
const SComplex & j05 = j0[4*ATOOLS::Spinor<SType>::R1()+1];
const SComplex & j06 = j0[4*ATOOLS::Spinor<SType>::R1()+2];
const SComplex & j07 = j0[4*ATOOLS::Spinor<SType>::R1()+3];
const SComplex & j08 = j0[4*ATOOLS::Spinor<SType>::R2()+0];
const SComplex & j09 = j0[4*ATOOLS::Spinor<SType>::R2()+1];
const SComplex & j010 = j0[4*ATOOLS::Spinor<SType>::R2()+2];
const SComplex & j011 = j0[4*ATOOLS::Spinor<SType>::R2()+3];
const SComplex & j012 = j0[4*ATOOLS::Spinor<SType>::R3()+0];
const SComplex & j013 = j0[4*ATOOLS::Spinor<SType>::R3()+1];
const SComplex & j014 = j0[4*ATOOLS::Spinor<SType>::R3()+2];
const SComplex & j015 = j0[4*ATOOLS::Spinor<SType>::R3()+3];
const ATOOLS::Vec4D & p0 = p_v->J(1)->P();
const double& p00 = p0[0];
const double& p01 = p0[ATOOLS::Spinor<SType>::R1()];
const double& p02 = p0[ATOOLS::Spinor<SType>::R2()];
const double& p03 = p0[ATOOLS::Spinor<SType>::R3()];
const CVec4<SType> & j2 = *(jj[0]->Get<CVec4<SType>>());
const SComplex & j20 = j2[0];
const SComplex & j21 = j2[ATOOLS::Spinor<SType>::R1()];
const SComplex & j22 = j2[ATOOLS::Spinor<SType>::R2()];
const SComplex & j23 = j2[ATOOLS::Spinor<SType>::R3()];
const ATOOLS::Vec4D & p2 = p_v->J(0)->P();
const double& p20 = p2[0];
const double& p21 = p2[ATOOLS::Spinor<SType>::R1()];
const double& p22 = p2[ATOOLS::Spinor<SType>::R2()];
const double& p23 = p2[ATOOLS::Spinor<SType>::R3()];
CSpinor<SType>* j1 = nullptr;
ATOOLS::Vec4D p1 = -p0-p2;
const double& p10 = p1[0];
const double& p11 = p1[ATOOLS::Spinor<SType>::R1()];
const double& p12 = p1[ATOOLS::Spinor<SType>::R2()];
const double& p13 = p1[ATOOLS::Spinor<SType>::R3()];
j1 = CSpinor<SType>::New(m_r[1],1,0,0,0,0,3);
(*j1)[0] = 1.0*j20*(-1.0*p01*j010 + 1.0*p02*j06 + 1.0*p03*j011 + 1.0*I*p03*j07 - 1.0*j015*(1.0*I*p01 + 1.0*p02)) - 1.0*j21*(-1.0*I*p00*j015 - 1.0*p02*j014 + 1.0*p02*j02 + 1.0*I*p03*j03 - 1.0*j010*(1.0*p00 - 1.0*p03)) - 1.0*j22*(-1.0*p00*j015 + 1.0*p01*j014 - 1.0*p01*j02 + 1.0*p03*j03 - 1.0*j06*(-1.0*p00 + 1.0*p03)) - 1.0*j23*(1.0*p00*j011 + 1.0*I*p00*j07 - 1.0*p01*j010 + 1.0*p02*j06 + 1.0*j03*(-1.0*I*p01 - 1.0*p02));
(*j1)[1] = 1.0*j20*(1.0*p01*j011 - 1.0*p02*j07 + 1.0*p03*j010 - 1.0*I*p03*j06 - 1.0*j014*(-1.0*I*p01 + 1.0*p02)) - 1.0*j21*(1.0*I*p00*j014 - 1.0*p02*j015 - 1.0*p02*j03 - 1.0*I*p03*j02 - 1.0*j011*(-1.0*p00 - 1.0*p03)) - 1.0*j22*(-1.0*p00*j014 + 1.0*p01*j015 + 1.0*p01*j03 + 1.0*p03*j02 - 1.0*j07*(1.0*p00 + 1.0*p03)) - 1.0*j23*(1.0*p00*j010 - 1.0*I*p00*j06 - 1.0*p01*j011 + 1.0*p02*j07 + 1.0*j02*(1.0*I*p01 - 1.0*p02));
(*j1)[2] = 1.0*j20*(-1.0*p01*j08 + 1.0*p02*j04 + 1.0*I*p03*j05 + 1.0*p03*j09 - 1.0*j013*(1.0*I*p01 + 1.0*p02)) - 1.0*j21*(-1.0*I*p00*j013 + 1.0*p02*j00 + 1.0*p02*j012 + 1.0*I*p03*j01 - 1.0*j08*(1.0*p00 + 1.0*p03)) - 1.0*j22*(-1.0*p00*j013 - 1.0*p01*j00 - 1.0*p01*j012 + 1.0*p03*j01 - 1.0*j04*(-1.0*p00 - 1.0*p03)) - 1.0*j23*(1.0*I*p00*j05 + 1.0*p00*j09 + 1.0*p01*j08 - 1.0*p02*j04 + 1.0*j01*(-1.0*I*p01 - 1.0*p02));
(*j1)[3] = 1.0*j20*(1.0*p01*j09 - 1.0*p02*j05 - 1.0*I*p03*j04 + 1.0*p03*j08 - 1.0*j012*(-1.0*I*p01 + 1.0*p02)) - 1.0*j21*(1.0*I*p00*j012 + 1.0*p02*j013 - 1.0*p02*j01 - 1.0*I*p03*j00 - 1.0*j09*(-1.0*p00 + 1.0*p03)) - 1.0*j22*(-1.0*p00*j012 - 1.0*p01*j013 + 1.0*p01*j01 + 1.0*p03*j00 - 1.0*j05*(1.0*p00 - 1.0*p03)) - 1.0*j23*(-1.0*I*p00*j04 + 1.0*p00*j08 + 1.0*p01*j09 - 1.0*p02*j05 + 1.0*j00*(1.0*I*p01 - 1.0*p02));
j1->SetS(j0.S()|j2.S());
return j1;
}
// if outgoing index is 2
if (p_v->V()->id.back()==2) {
const CRaritaSchwinger<SType> & j0 = ((jj[0]->Get<CRaritaSchwinger<SType>>())->B() == 1 ? (*(jj[0]->Get<CRaritaSchwinger<SType>>())) : (*(jj[0]->Get<CRaritaSchwinger<SType>>())).CConj());
const SComplex & j00 = j0[4*0+0];
const SComplex & j01 = j0[4*0+1];
const SComplex & j02 = j0[4*0+2];
const SComplex & j03 = j0[4*0+3];
const SComplex & j04 = j0[4*ATOOLS::Spinor<SType>::R1()+0];
const SComplex & j05 = j0[4*ATOOLS::Spinor<SType>::R1()+1];
const SComplex & j06 = j0[4*ATOOLS::Spinor<SType>::R1()+2];
const SComplex & j07 = j0[4*ATOOLS::Spinor<SType>::R1()+3];
const SComplex & j08 = j0[4*ATOOLS::Spinor<SType>::R2()+0];
const SComplex & j09 = j0[4*ATOOLS::Spinor<SType>::R2()+1];
const SComplex & j010 = j0[4*ATOOLS::Spinor<SType>::R2()+2];
const SComplex & j011 = j0[4*ATOOLS::Spinor<SType>::R2()+3];
const SComplex & j012 = j0[4*ATOOLS::Spinor<SType>::R3()+0];
const SComplex & j013 = j0[4*ATOOLS::Spinor<SType>::R3()+1];
const SComplex & j014 = j0[4*ATOOLS::Spinor<SType>::R3()+2];
const SComplex & j015 = j0[4*ATOOLS::Spinor<SType>::R3()+3];
const ATOOLS::Vec4D & p0 = p_v->J(0)->P();
const double& p00 = p0[0];
const double& p01 = p0[ATOOLS::Spinor<SType>::R1()];
const double& p02 = p0[ATOOLS::Spinor<SType>::R2()];
const double& p03 = p0[ATOOLS::Spinor<SType>::R3()];
const CSpinor<SType> & j1 = ((jj[1]->Get<CSpinor<SType>>())->B() == -1 ? (*(jj[1]->Get<CSpinor<SType>>())) : (*(jj[1]->Get<CSpinor<SType>>())).CConj());
const SComplex & j10 = j1[0];
const SComplex & j11 = j1[1];
const SComplex & j12 = j1[2];
const SComplex & j13 = j1[3];
const ATOOLS::Vec4D & p1 = p_v->J(1)->P();
const double& p10 = p1[0];
const double& p11 = p1[ATOOLS::Spinor<SType>::R1()];
const double& p12 = p1[ATOOLS::Spinor<SType>::R2()];
const double& p13 = p1[ATOOLS::Spinor<SType>::R3()];
CVec4<SType>* j2 = nullptr;
ATOOLS::Vec4D p2 = -p0-p1;
const double& p20 = p2[0];
const double& p21 = p2[ATOOLS::Spinor<SType>::R1()];
const double& p22 = p2[ATOOLS::Spinor<SType>::R2()];
const double& p23 = p2[ATOOLS::Spinor<SType>::R3()];
j2 = CVec4<SType>::New();
(*j2)[0] = j10*(-1.0*p01*j010 + 1.0*p02*j06 + 1.0*p03*j011 + 1.0*I*p03*j07 - 1.0*j015*(1.0*I*p01 + 1.0*p02)) + j11*(1.0*p01*j011 - 1.0*p02*j07 + 1.0*p03*j010 - 1.0*I*p03*j06 - 1.0*j014*(-1.0*I*p01 + 1.0*p02)) + j12*(-1.0*p01*j08 + 1.0*p02*j04 + 1.0*I*p03*j05 + 1.0*p03*j09 - 1.0*j013*(1.0*I*p01 + 1.0*p02)) + j13*(1.0*p01*j09 - 1.0*p02*j05 - 1.0*I*p03*j04 + 1.0*p03*j08 - 1.0*j012*(-1.0*I*p01 + 1.0*p02));
(*j2)[ATOOLS::Spinor<SType>::R1()] = j10*(-1.0*I*p00*j015 - 1.0*p02*j014 + 1.0*p02*j02 + 1.0*I*p03*j03 - 1.0*j010*(1.0*p00 - 1.0*p03)) + j11*(1.0*I*p00*j014 - 1.0*p02*j015 - 1.0*p02*j03 - 1.0*I*p03*j02 - 1.0*j011*(-1.0*p00 - 1.0*p03)) + j12*(-1.0*I*p00*j013 + 1.0*p02*j00 + 1.0*p02*j012 + 1.0*I*p03*j01 - 1.0*j08*(1.0*p00 + 1.0*p03)) + j13*(1.0*I*p00*j012 + 1.0*p02*j013 - 1.0*p02*j01 - 1.0*I*p03*j00 - 1.0*j09*(-1.0*p00 + 1.0*p03));
(*j2)[ATOOLS::Spinor<SType>::R2()] = j10*(-1.0*p00*j015 + 1.0*p01*j014 - 1.0*p01*j02 + 1.0*p03*j03 - 1.0*j06*(-1.0*p00 + 1.0*p03)) + j11*(-1.0*p00*j014 + 1.0*p01*j015 + 1.0*p01*j03 + 1.0*p03*j02 - 1.0*j07*(1.0*p00 + 1.0*p03)) + j12*(-1.0*p00*j013 - 1.0*p01*j00 - 1.0*p01*j012 + 1.0*p03*j01 - 1.0*j04*(-1.0*p00 - 1.0*p03)) + j13*(-1.0*p00*j012 - 1.0*p01*j013 + 1.0*p01*j01 + 1.0*p03*j00 - 1.0*j05*(1.0*p00 - 1.0*p03));
(*j2)[ATOOLS::Spinor<SType>::R3()] = j10*(1.0*p00*j011 + 1.0*I*p00*j07 - 1.0*p01*j010 + 1.0*p02*j06 + 1.0*j03*(-1.0*I*p01 - 1.0*p02)) + j11*(1.0*p00*j010 - 1.0*I*p00*j06 - 1.0*p01*j011 + 1.0*p02*j07 + 1.0*j02*(1.0*I*p01 - 1.0*p02)) + j12*(1.0*I*p00*j05 + 1.0*p00*j09 + 1.0*p01*j08 - 1.0*p02*j04 + 1.0*j01*(-1.0*I*p01 - 1.0*p02)) + j13*(-1.0*I*p00*j04 + 1.0*p00*j08 + 1.0*p01*j09 - 1.0*p02*j05 + 1.0*j00*(1.0*I*p01 - 1.0*p02));
j2->SetS(j0.S()|j1.S());
return j2;
}

      THROW(fatal_error, "Internal error in Lorentz calculator");
      return NULL;
    }

    virtual std::string FormFactor() const { return "None"; }


  };// end of class RFV1_Calculator

  template class RFV1_Calculator<double>;

}// end of namespace METOOLS


using namespace METOOLS;

DECLARE_GETTER(RFV1_Calculator<double>,"DRFV1",
	       Lorentz_Calculator,Vertex_Key);
Lorentz_Calculator *ATOOLS::Getter
<Lorentz_Calculator,Vertex_Key,RFV1_Calculator<double> >::
operator()(const Vertex_Key &key) const
{ return new RFV1_Calculator<double>(key); }

void ATOOLS::Getter<Lorentz_Calculator,Vertex_Key,
		    RFV1_Calculator<double> >::
PrintInfo(std::ostream &str,const size_t width) const
{ str<<"RFV1 vertex"; }
