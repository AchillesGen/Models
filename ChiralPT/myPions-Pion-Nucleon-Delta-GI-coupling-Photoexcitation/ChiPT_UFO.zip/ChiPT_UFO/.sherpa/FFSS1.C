#include "METOOLS/Explicit/Lorentz_Calculator.H"
#include "METOOLS/Currents/C_Scalar.H"
#include "METOOLS/Currents/C_Spinor.H"
#include "METOOLS/Currents/C_Vector.H"
#include "METOOLS/Currents/C_RaritaSchwinger.H"
#include "METOOLS/Explicit/Vertex.H"
#include "METOOLS/Explicit/Form_Factor.H"
#include "MODEL/Main/Single_Vertex.H"
#include "ATOOLS/Org/Message.H"
#include "ATOOLS/Org/Exception.H"
#include "ATOOLS/Math/MyComplex.H"

namespace METOOLS {

  template <typename SType>
  class FFSS1_Calculator: public Lorentz_Calculator {
  public:

    typedef std::complex<SType> SComplex;

    const SComplex I = SComplex(0.0,1.0);
    
    FFSS1_Calculator(const Vertex_Key &key):
      Lorentz_Calculator(key) {

    }

    std::string Label() const { return "FFSS1"; }

    CObject *Evaluate(const CObject_Vector &jj)
    {
// if outgoing index is 0
if (p_v->V()->id.back()==0) {
const CSpinor<SType> & j1 = ((jj[0]->Get<CSpinor<SType>>())->B() == -1 ? (*(jj[0]->Get<CSpinor<SType>>())) : (*(jj[0]->Get<CSpinor<SType>>())).CConj());
const SComplex & j10 = j1[0];
const SComplex & j11 = j1[1];
const SComplex & j12 = j1[2];
const SComplex & j13 = j1[3];
const ATOOLS::Vec4D & p1 = p_v->J(0)->P();
const double& p10 = p1[0];
const double& p11 = p1[ATOOLS::Spinor<SType>::R1()];
const double& p12 = p1[ATOOLS::Spinor<SType>::R2()];
const double& p13 = p1[ATOOLS::Spinor<SType>::R3()];
const CScalar<SType> & j2 = *(jj[1]->Get<CScalar<SType>>());
const SComplex & j20 = j2[0];
const ATOOLS::Vec4D & p2 = p_v->J(1)->P();
const double& p20 = p2[0];
const double& p21 = p2[ATOOLS::Spinor<SType>::R1()];
const double& p22 = p2[ATOOLS::Spinor<SType>::R2()];
const double& p23 = p2[ATOOLS::Spinor<SType>::R3()];
const CScalar<SType> & j3 = *(jj[2]->Get<CScalar<SType>>());
const SComplex & j30 = j3[0];
const ATOOLS::Vec4D & p3 = p_v->J(2)->P();
const double& p30 = p3[0];
const double& p31 = p3[ATOOLS::Spinor<SType>::R1()];
const double& p32 = p3[ATOOLS::Spinor<SType>::R2()];
const double& p33 = p3[ATOOLS::Spinor<SType>::R3()];
CSpinor<SType>* j0 = nullptr;
ATOOLS::Vec4D p0 = -p1-p2-p3;
const double& p00 = p0[0];
const double& p01 = p0[ATOOLS::Spinor<SType>::R1()];
const double& p02 = p0[ATOOLS::Spinor<SType>::R2()];
const double& p03 = p0[ATOOLS::Spinor<SType>::R3()];
j0 = CSpinor<SType>::New(m_r[0],-1,0,0,0,0,3);
(*j0)[0] = j20*j30*(j12*(1.0*p20 + 1.0*p23 - 1.0*p30 - 1.0*p33) + j13*(1.0*p21 + 1.0*I*p22 - 1.0*p31 - 1.0*I*p32));
(*j0)[1] = j20*j30*(j12*(1.0*p21 - 1.0*I*p22 - 1.0*p31 + 1.0*I*p32) + j13*(1.0*p20 - 1.0*p23 - 1.0*p30 + 1.0*p33));
(*j0)[2] = j20*j30*(j10*(1.0*p20 - 1.0*p23 - 1.0*p30 + 1.0*p33) + j11*(-1.0*p21 - 1.0*I*p22 + 1.0*p31 + 1.0*I*p32));
(*j0)[3] = j20*j30*(j10*(-1.0*p21 + 1.0*I*p22 + 1.0*p31 - 1.0*I*p32) + j11*(1.0*p20 + 1.0*p23 - 1.0*p30 - 1.0*p33));
j0->SetS(j1.S()|j2.S()|j3.S());
return j0;
}
// if outgoing index is 1
if (p_v->V()->id.back()==1) {
const CSpinor<SType> & j0 = ((jj[2]->Get<CSpinor<SType>>())->B() == 1 ? (*(jj[2]->Get<CSpinor<SType>>())) : (*(jj[2]->Get<CSpinor<SType>>())).CConj());
const SComplex & j00 = j0[0];
const SComplex & j01 = j0[1];
const SComplex & j02 = j0[2];
const SComplex & j03 = j0[3];
const ATOOLS::Vec4D & p0 = p_v->J(2)->P();
const double& p00 = p0[0];
const double& p01 = p0[ATOOLS::Spinor<SType>::R1()];
const double& p02 = p0[ATOOLS::Spinor<SType>::R2()];
const double& p03 = p0[ATOOLS::Spinor<SType>::R3()];
const CScalar<SType> & j2 = *(jj[0]->Get<CScalar<SType>>());
const SComplex & j20 = j2[0];
const ATOOLS::Vec4D & p2 = p_v->J(0)->P();
const double& p20 = p2[0];
const double& p21 = p2[ATOOLS::Spinor<SType>::R1()];
const double& p22 = p2[ATOOLS::Spinor<SType>::R2()];
const double& p23 = p2[ATOOLS::Spinor<SType>::R3()];
const CScalar<SType> & j3 = *(jj[1]->Get<CScalar<SType>>());
const SComplex & j30 = j3[0];
const ATOOLS::Vec4D & p3 = p_v->J(1)->P();
const double& p30 = p3[0];
const double& p31 = p3[ATOOLS::Spinor<SType>::R1()];
const double& p32 = p3[ATOOLS::Spinor<SType>::R2()];
const double& p33 = p3[ATOOLS::Spinor<SType>::R3()];
CSpinor<SType>* j1 = nullptr;
ATOOLS::Vec4D p1 = -p0-p2-p3;
const double& p10 = p1[0];
const double& p11 = p1[ATOOLS::Spinor<SType>::R1()];
const double& p12 = p1[ATOOLS::Spinor<SType>::R2()];
const double& p13 = p1[ATOOLS::Spinor<SType>::R3()];
j1 = CSpinor<SType>::New(m_r[1],1,0,0,0,0,3);
(*j1)[0] = j20*j30*(j02*(1.0*p20 - 1.0*p23 - 1.0*p30 + 1.0*p33) + j03*(-1.0*p21 + 1.0*I*p22 + 1.0*p31 - 1.0*I*p32));
(*j1)[1] = j20*j30*(j02*(-1.0*p21 - 1.0*I*p22 + 1.0*p31 + 1.0*I*p32) + j03*(1.0*p20 + 1.0*p23 - 1.0*p30 - 1.0*p33));
(*j1)[2] = j20*j30*(j00*(1.0*p20 + 1.0*p23 - 1.0*p30 - 1.0*p33) + j01*(1.0*p21 - 1.0*I*p22 - 1.0*p31 + 1.0*I*p32));
(*j1)[3] = j20*j30*(j00*(1.0*p21 + 1.0*I*p22 - 1.0*p31 - 1.0*I*p32) + j01*(1.0*p20 - 1.0*p23 - 1.0*p30 + 1.0*p33));
j1->SetS(j0.S()|j2.S()|j3.S());
return j1;
}
// if outgoing index is 2
if (p_v->V()->id.back()==2) {
const CSpinor<SType> & j0 = ((jj[1]->Get<CSpinor<SType>>())->B() == 1 ? (*(jj[1]->Get<CSpinor<SType>>())) : (*(jj[1]->Get<CSpinor<SType>>())).CConj());
const SComplex & j00 = j0[0];
const SComplex & j01 = j0[1];
const SComplex & j02 = j0[2];
const SComplex & j03 = j0[3];
const ATOOLS::Vec4D & p0 = p_v->J(1)->P();
const double& p00 = p0[0];
const double& p01 = p0[ATOOLS::Spinor<SType>::R1()];
const double& p02 = p0[ATOOLS::Spinor<SType>::R2()];
const double& p03 = p0[ATOOLS::Spinor<SType>::R3()];
const CSpinor<SType> & j1 = ((jj[2]->Get<CSpinor<SType>>())->B() == -1 ? (*(jj[2]->Get<CSpinor<SType>>())) : (*(jj[2]->Get<CSpinor<SType>>())).CConj());
const SComplex & j10 = j1[0];
const SComplex & j11 = j1[1];
const SComplex & j12 = j1[2];
const SComplex & j13 = j1[3];
const ATOOLS::Vec4D & p1 = p_v->J(2)->P();
const double& p10 = p1[0];
const double& p11 = p1[ATOOLS::Spinor<SType>::R1()];
const double& p12 = p1[ATOOLS::Spinor<SType>::R2()];
const double& p13 = p1[ATOOLS::Spinor<SType>::R3()];
const CScalar<SType> & j3 = *(jj[0]->Get<CScalar<SType>>());
const SComplex & j30 = j3[0];
const ATOOLS::Vec4D & p3 = p_v->J(0)->P();
const double& p30 = p3[0];
const double& p31 = p3[ATOOLS::Spinor<SType>::R1()];
const double& p32 = p3[ATOOLS::Spinor<SType>::R2()];
const double& p33 = p3[ATOOLS::Spinor<SType>::R3()];
CScalar<SType>* j2 = nullptr;
ATOOLS::Vec4D p2 = -p0-p1-p3;
const double& p20 = p2[0];
const double& p21 = p2[ATOOLS::Spinor<SType>::R1()];
const double& p22 = p2[ATOOLS::Spinor<SType>::R2()];
const double& p23 = p2[ATOOLS::Spinor<SType>::R3()];
j2 = CScalar<SType>::New();
(*j2) = j30*(j10*(j02*(1.0*p20 - 1.0*p23 - 1.0*p30 + 1.0*p33) + j03*(-1.0*p21 + 1.0*I*p22 + 1.0*p31 - 1.0*I*p32)) + j11*(j02*(-1.0*p21 - 1.0*I*p22 + 1.0*p31 + 1.0*I*p32) + j03*(1.0*p20 + 1.0*p23 - 1.0*p30 - 1.0*p33)) + j12*(j00*(1.0*p20 + 1.0*p23 - 1.0*p30 - 1.0*p33) + j01*(1.0*p21 - 1.0*I*p22 - 1.0*p31 + 1.0*I*p32)) + j13*(j00*(1.0*p21 + 1.0*I*p22 - 1.0*p31 - 1.0*I*p32) + j01*(1.0*p20 - 1.0*p23 - 1.0*p30 + 1.0*p33)));
j2->SetS(j0.S()|j1.S()|j3.S());
return j2;
}
// if outgoing index is 3
if (p_v->V()->id.back()==3) {
const CSpinor<SType> & j0 = ((jj[0]->Get<CSpinor<SType>>())->B() == 1 ? (*(jj[0]->Get<CSpinor<SType>>())) : (*(jj[0]->Get<CSpinor<SType>>())).CConj());
const SComplex & j00 = j0[0];
const SComplex & j01 = j0[1];
const SComplex & j02 = j0[2];
const SComplex & j03 = j0[3];
const ATOOLS::Vec4D & p0 = p_v->J(0)->P();
const double& p00 = p0[0];
const double& p01 = p0[ATOOLS::Spinor<SType>::R1()];
const double& p02 = p0[ATOOLS::Spinor<SType>::R2()];
const double& p03 = p0[ATOOLS::Spinor<SType>::R3()];
const CSpinor<SType> & j1 = ((jj[1]->Get<CSpinor<SType>>())->B() == -1 ? (*(jj[1]->Get<CSpinor<SType>>())) : (*(jj[1]->Get<CSpinor<SType>>())).CConj());
const SComplex & j10 = j1[0];
const SComplex & j11 = j1[1];
const SComplex & j12 = j1[2];
const SComplex & j13 = j1[3];
const ATOOLS::Vec4D & p1 = p_v->J(1)->P();
const double& p10 = p1[0];
const double& p11 = p1[ATOOLS::Spinor<SType>::R1()];
const double& p12 = p1[ATOOLS::Spinor<SType>::R2()];
const double& p13 = p1[ATOOLS::Spinor<SType>::R3()];
const CScalar<SType> & j2 = *(jj[2]->Get<CScalar<SType>>());
const SComplex & j20 = j2[0];
const ATOOLS::Vec4D & p2 = p_v->J(2)->P();
const double& p20 = p2[0];
const double& p21 = p2[ATOOLS::Spinor<SType>::R1()];
const double& p22 = p2[ATOOLS::Spinor<SType>::R2()];
const double& p23 = p2[ATOOLS::Spinor<SType>::R3()];
CScalar<SType>* j3 = nullptr;
ATOOLS::Vec4D p3 = -p0-p1-p2;
const double& p30 = p3[0];
const double& p31 = p3[ATOOLS::Spinor<SType>::R1()];
const double& p32 = p3[ATOOLS::Spinor<SType>::R2()];
const double& p33 = p3[ATOOLS::Spinor<SType>::R3()];
j3 = CScalar<SType>::New();
(*j3) = j20*(j10*(j02*(1.0*p20 - 1.0*p23 - 1.0*p30 + 1.0*p33) + j03*(-1.0*p21 + 1.0*I*p22 + 1.0*p31 - 1.0*I*p32)) + j11*(j02*(-1.0*p21 - 1.0*I*p22 + 1.0*p31 + 1.0*I*p32) + j03*(1.0*p20 + 1.0*p23 - 1.0*p30 - 1.0*p33)) + j12*(j00*(1.0*p20 + 1.0*p23 - 1.0*p30 - 1.0*p33) + j01*(1.0*p21 - 1.0*I*p22 - 1.0*p31 + 1.0*I*p32)) + j13*(j00*(1.0*p21 + 1.0*I*p22 - 1.0*p31 - 1.0*I*p32) + j01*(1.0*p20 - 1.0*p23 - 1.0*p30 + 1.0*p33)));
j3->SetS(j0.S()|j1.S()|j2.S());
return j3;
}

      THROW(fatal_error, "Internal error in Lorentz calculator");
      return NULL;
    }

    virtual std::string FormFactor() const { return "None"; }


  };// end of class FFSS1_Calculator

  template class FFSS1_Calculator<double>;

}// end of namespace METOOLS


using namespace METOOLS;

DECLARE_GETTER(FFSS1_Calculator<double>,"DFFSS1",
	       Lorentz_Calculator,Vertex_Key);
Lorentz_Calculator *ATOOLS::Getter
<Lorentz_Calculator,Vertex_Key,FFSS1_Calculator<double> >::
operator()(const Vertex_Key &key) const
{ return new FFSS1_Calculator<double>(key); }

void ATOOLS::Getter<Lorentz_Calculator,Vertex_Key,
		    FFSS1_Calculator<double> >::
PrintInfo(std::ostream &str,const size_t width) const
{ str<<"FFSS1 vertex"; }
