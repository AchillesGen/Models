#include "METOOLS/Explicit/Lorentz_Calculator.H"
#include "METOOLS/Currents/C_Scalar.H"
#include "METOOLS/Currents/C_Spinor.H"
#include "METOOLS/Currents/C_Vector.H"
#include "METOOLS/Currents/C_RaritaSchwinger.H"
#include "METOOLS/Explicit/Vertex.H"
#include "METOOLS/Explicit/Form_Factor.H"
#include "MODEL/Main/Single_Vertex.H"
#include "ATOOLS/Org/Message.H"
#include "ATOOLS/Org/Exception.H"
#include "ATOOLS/Math/MyComplex.H"

namespace METOOLS {

  template <typename SType>
  class FRV1_Calculator: public Lorentz_Calculator {
  public:

    typedef std::complex<SType> SComplex;

    const SComplex I = SComplex(0.0,1.0);
    
    FRV1_Calculator(const Vertex_Key &key):
      Lorentz_Calculator(key) {

    }

    std::string Label() const { return "FRV1"; }

    CObject *Evaluate(const CObject_Vector &jj)
    {
// if outgoing index is 0
if (p_v->V()->id.back()==0) {
const CRaritaSchwinger<SType> & j1 = ((jj[0]->Get<CRaritaSchwinger<SType>>())->B() == -1 ? (*(jj[0]->Get<CRaritaSchwinger<SType>>())) : (*(jj[0]->Get<CRaritaSchwinger<SType>>())).CConj());
const SComplex & j10 = j1[4*0+0];
const SComplex & j11 = j1[4*0+1];
const SComplex & j12 = j1[4*0+2];
const SComplex & j13 = j1[4*0+3];
const SComplex & j14 = j1[4*ATOOLS::Spinor<SType>::R1()+0];
const SComplex & j15 = j1[4*ATOOLS::Spinor<SType>::R1()+1];
const SComplex & j16 = j1[4*ATOOLS::Spinor<SType>::R1()+2];
const SComplex & j17 = j1[4*ATOOLS::Spinor<SType>::R1()+3];
const SComplex & j18 = j1[4*ATOOLS::Spinor<SType>::R2()+0];
const SComplex & j19 = j1[4*ATOOLS::Spinor<SType>::R2()+1];
const SComplex & j110 = j1[4*ATOOLS::Spinor<SType>::R2()+2];
const SComplex & j111 = j1[4*ATOOLS::Spinor<SType>::R2()+3];
const SComplex & j112 = j1[4*ATOOLS::Spinor<SType>::R3()+0];
const SComplex & j113 = j1[4*ATOOLS::Spinor<SType>::R3()+1];
const SComplex & j114 = j1[4*ATOOLS::Spinor<SType>::R3()+2];
const SComplex & j115 = j1[4*ATOOLS::Spinor<SType>::R3()+3];
const ATOOLS::Vec4D & p1 = p_v->J(0)->P();
const double& p10 = p1[0];
const double& p11 = p1[ATOOLS::Spinor<SType>::R1()];
const double& p12 = p1[ATOOLS::Spinor<SType>::R2()];
const double& p13 = p1[ATOOLS::Spinor<SType>::R3()];
const CVec4<SType> & j2 = *(jj[1]->Get<CVec4<SType>>());
const SComplex & j20 = j2[0];
const SComplex & j21 = j2[ATOOLS::Spinor<SType>::R1()];
const SComplex & j22 = j2[ATOOLS::Spinor<SType>::R2()];
const SComplex & j23 = j2[ATOOLS::Spinor<SType>::R3()];
const ATOOLS::Vec4D & p2 = p_v->J(1)->P();
const double& p20 = p2[0];
const double& p21 = p2[ATOOLS::Spinor<SType>::R1()];
const double& p22 = p2[ATOOLS::Spinor<SType>::R2()];
const double& p23 = p2[ATOOLS::Spinor<SType>::R3()];
CSpinor<SType>* j0 = nullptr;
ATOOLS::Vec4D p0 = -p1-p2;
const double& p00 = p0[0];
const double& p01 = p0[ATOOLS::Spinor<SType>::R1()];
const double& p02 = p0[ATOOLS::Spinor<SType>::R2()];
const double& p03 = p0[ATOOLS::Spinor<SType>::R3()];
j0 = CSpinor<SType>::New(m_r[0],-1,0,0,0,0,3);
(*j0)[0] = 1.0*j20*(-1.0*p11*j110 + 1.0*p12*j16 + 1.0*p13*j111 - 1.0*I*p13*j17 - 1.0*j115*(-1.0*I*p11 + 1.0*p12)) - 1.0*j21*(1.0*I*p10*j115 + 1.0*p12*j114 + 1.0*p12*j12 - 1.0*I*p13*j13 - 1.0*j110*(1.0*p10 + 1.0*p13)) - 1.0*j22*(-1.0*p10*j115 - 1.0*p11*j114 - 1.0*p11*j12 + 1.0*p13*j13 - 1.0*j16*(-1.0*p10 - 1.0*p13)) - 1.0*j23*(1.0*p10*j111 - 1.0*I*p10*j17 + 1.0*p11*j110 - 1.0*p12*j16 + 1.0*j13*(1.0*I*p11 - 1.0*p12));
(*j0)[1] = 1.0*j20*(1.0*p11*j111 - 1.0*p12*j17 + 1.0*p13*j110 + 1.0*I*p13*j16 - 1.0*j114*(1.0*I*p11 + 1.0*p12)) - 1.0*j21*(-1.0*I*p10*j114 + 1.0*p12*j115 - 1.0*p12*j13 + 1.0*I*p13*j12 - 1.0*j111*(-1.0*p10 + 1.0*p13)) - 1.0*j22*(-1.0*p10*j114 - 1.0*p11*j115 + 1.0*p11*j13 + 1.0*p13*j12 - 1.0*j17*(1.0*p10 - 1.0*p13)) - 1.0*j23*(1.0*p10*j110 + 1.0*I*p10*j16 + 1.0*p11*j111 - 1.0*p12*j17 + 1.0*j12*(-1.0*I*p11 - 1.0*p12));
(*j0)[2] = 1.0*j20*(-1.0*p11*j18 + 1.0*p12*j14 - 1.0*I*p13*j15 + 1.0*p13*j19 - 1.0*j113*(-1.0*I*p11 + 1.0*p12)) - 1.0*j21*(1.0*I*p10*j113 + 1.0*p12*j10 - 1.0*p12*j112 - 1.0*I*p13*j11 - 1.0*j18*(1.0*p10 - 1.0*p13)) - 1.0*j22*(-1.0*p10*j113 - 1.0*p11*j10 + 1.0*p11*j112 + 1.0*p13*j11 - 1.0*j14*(-1.0*p10 + 1.0*p13)) - 1.0*j23*(-1.0*I*p10*j15 + 1.0*p10*j19 - 1.0*p11*j18 + 1.0*p12*j14 + 1.0*j11*(1.0*I*p11 - 1.0*p12));
(*j0)[3] = 1.0*j20*(1.0*p11*j19 - 1.0*p12*j15 + 1.0*I*p13*j14 + 1.0*p13*j18 - 1.0*j112*(1.0*I*p11 + 1.0*p12)) - 1.0*j21*(-1.0*I*p10*j112 - 1.0*p12*j113 - 1.0*p12*j11 + 1.0*I*p13*j10 - 1.0*j19*(-1.0*p10 - 1.0*p13)) - 1.0*j22*(-1.0*p10*j112 + 1.0*p11*j113 + 1.0*p11*j11 + 1.0*p13*j10 - 1.0*j15*(1.0*p10 + 1.0*p13)) - 1.0*j23*(1.0*I*p10*j14 + 1.0*p10*j18 - 1.0*p11*j19 + 1.0*p12*j15 + 1.0*j10*(-1.0*I*p11 - 1.0*p12));
j0->SetS(j1.S()|j2.S());
return j0;
}
// if outgoing index is 1
if (p_v->V()->id.back()==1) {
const CSpinor<SType> & j0 = ((jj[1]->Get<CSpinor<SType>>())->B() == 1 ? (*(jj[1]->Get<CSpinor<SType>>())) : (*(jj[1]->Get<CSpinor<SType>>())).CConj());
const SComplex & j00 = j0[0];
const SComplex & j01 = j0[1];
const SComplex & j02 = j0[2];
const SComplex & j03 = j0[3];
const ATOOLS::Vec4D & p0 = p_v->J(1)->P();
const double& p00 = p0[0];
const double& p01 = p0[ATOOLS::Spinor<SType>::R1()];
const double& p02 = p0[ATOOLS::Spinor<SType>::R2()];
const double& p03 = p0[ATOOLS::Spinor<SType>::R3()];
const CVec4<SType> & j2 = *(jj[0]->Get<CVec4<SType>>());
const SComplex & j20 = j2[0];
const SComplex & j21 = j2[ATOOLS::Spinor<SType>::R1()];
const SComplex & j22 = j2[ATOOLS::Spinor<SType>::R2()];
const SComplex & j23 = j2[ATOOLS::Spinor<SType>::R3()];
const ATOOLS::Vec4D & p2 = p_v->J(0)->P();
const double& p20 = p2[0];
const double& p21 = p2[ATOOLS::Spinor<SType>::R1()];
const double& p22 = p2[ATOOLS::Spinor<SType>::R2()];
const double& p23 = p2[ATOOLS::Spinor<SType>::R3()];
CRaritaSchwinger<SType>* j1 = nullptr;
ATOOLS::Vec4D p1 = -p0-p2;
const double& p10 = p1[0];
const double& p11 = p1[ATOOLS::Spinor<SType>::R1()];
const double& p12 = p1[ATOOLS::Spinor<SType>::R2()];
const double& p13 = p1[ATOOLS::Spinor<SType>::R3()];
j1 = CRaritaSchwinger<SType>::New(m_r[1],1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
(*j1)[0*4+0] = 1.0*p11*j02*j22 - 1.0*p12*j02*j21 - 1.0*I*p13*j03*j21 - 1.0*p13*j03*j22 - 1.0*j03*j23*(-1.0*I*p11 - 1.0*p12);
(*j1)[0*4+1] = -1.0*p11*j03*j22 + 1.0*p12*j03*j21 + 1.0*I*p13*j02*j21 - 1.0*p13*j02*j22 - 1.0*j02*j23*(1.0*I*p11 - 1.0*p12);
(*j1)[0*4+2] = 1.0*p11*j00*j22 - 1.0*p12*j00*j21 - 1.0*I*p13*j01*j21 - 1.0*p13*j01*j22 - 1.0*j01*j23*(-1.0*I*p11 - 1.0*p12);
(*j1)[0*4+3] = -1.0*p11*j01*j22 + 1.0*p12*j01*j21 + 1.0*I*p13*j00*j21 - 1.0*p13*j00*j22 - 1.0*j00*j23*(1.0*I*p11 - 1.0*p12);
(*j1)[ATOOLS::Spinor<SType>::R1()*4+0] = 1.0*I*p10*j03*j23 - 1.0*p12*j02*j20 + 1.0*p12*j02*j23 - 1.0*I*p13*j03*j20 - 1.0*j02*j22*(-1.0*p10 + 1.0*p13);
(*j1)[ATOOLS::Spinor<SType>::R1()*4+1] = -1.0*I*p10*j02*j23 + 1.0*p12*j03*j20 + 1.0*p12*j03*j23 + 1.0*I*p13*j02*j20 - 1.0*j03*j22*(1.0*p10 + 1.0*p13);
(*j1)[ATOOLS::Spinor<SType>::R1()*4+2] = 1.0*I*p10*j01*j23 - 1.0*p12*j00*j20 - 1.0*p12*j00*j23 - 1.0*I*p13*j01*j20 - 1.0*j00*j22*(-1.0*p10 - 1.0*p13);
(*j1)[ATOOLS::Spinor<SType>::R1()*4+3] = -1.0*I*p10*j00*j23 + 1.0*p12*j01*j20 - 1.0*p12*j01*j23 + 1.0*I*p13*j00*j20 - 1.0*j01*j22*(1.0*p10 - 1.0*p13);
(*j1)[ATOOLS::Spinor<SType>::R2()*4+0] = 1.0*p10*j03*j23 + 1.0*p11*j02*j20 - 1.0*p11*j02*j23 - 1.0*p13*j03*j20 - 1.0*j02*j21*(1.0*p10 - 1.0*p13);
(*j1)[ATOOLS::Spinor<SType>::R2()*4+1] = 1.0*p10*j02*j23 - 1.0*p11*j03*j20 - 1.0*p11*j03*j23 - 1.0*p13*j02*j20 - 1.0*j03*j21*(-1.0*p10 - 1.0*p13);
(*j1)[ATOOLS::Spinor<SType>::R2()*4+2] = 1.0*p10*j01*j23 + 1.0*p11*j00*j20 + 1.0*p11*j00*j23 - 1.0*p13*j01*j20 - 1.0*j00*j21*(1.0*p10 + 1.0*p13);
(*j1)[ATOOLS::Spinor<SType>::R2()*4+3] = 1.0*p10*j00*j23 - 1.0*p11*j01*j20 + 1.0*p11*j01*j23 - 1.0*p13*j00*j20 - 1.0*j01*j21*(-1.0*p10 + 1.0*p13);
(*j1)[ATOOLS::Spinor<SType>::R3()*4+0] = -1.0*I*p10*j03*j21 - 1.0*p10*j03*j22 + 1.0*p11*j02*j22 - 1.0*p12*j02*j21 + 1.0*j03*j20*(1.0*I*p11 + 1.0*p12);
(*j1)[ATOOLS::Spinor<SType>::R3()*4+1] = 1.0*I*p10*j02*j21 - 1.0*p10*j02*j22 + 1.0*p11*j03*j22 - 1.0*p12*j03*j21 + 1.0*j02*j20*(-1.0*I*p11 + 1.0*p12);
(*j1)[ATOOLS::Spinor<SType>::R3()*4+2] = -1.0*I*p10*j01*j21 - 1.0*p10*j01*j22 - 1.0*p11*j00*j22 + 1.0*p12*j00*j21 + 1.0*j01*j20*(1.0*I*p11 + 1.0*p12);
(*j1)[ATOOLS::Spinor<SType>::R3()*4+3] = 1.0*I*p10*j00*j21 - 1.0*p10*j00*j22 - 1.0*p11*j01*j22 + 1.0*p12*j01*j21 + 1.0*j00*j20*(-1.0*I*p11 + 1.0*p12);
j1->SetS(j0.S()|j2.S());
return j1;
}
// if outgoing index is 2
if (p_v->V()->id.back()==2) {
const CSpinor<SType> & j0 = ((jj[0]->Get<CSpinor<SType>>())->B() == 1 ? (*(jj[0]->Get<CSpinor<SType>>())) : (*(jj[0]->Get<CSpinor<SType>>())).CConj());
const SComplex & j00 = j0[0];
const SComplex & j01 = j0[1];
const SComplex & j02 = j0[2];
const SComplex & j03 = j0[3];
const ATOOLS::Vec4D & p0 = p_v->J(0)->P();
const double& p00 = p0[0];
const double& p01 = p0[ATOOLS::Spinor<SType>::R1()];
const double& p02 = p0[ATOOLS::Spinor<SType>::R2()];
const double& p03 = p0[ATOOLS::Spinor<SType>::R3()];
const CRaritaSchwinger<SType> & j1 = ((jj[1]->Get<CRaritaSchwinger<SType>>())->B() == -1 ? (*(jj[1]->Get<CRaritaSchwinger<SType>>())) : (*(jj[1]->Get<CRaritaSchwinger<SType>>())).CConj());
const SComplex & j10 = j1[4*0+0];
const SComplex & j11 = j1[4*0+1];
const SComplex & j12 = j1[4*0+2];
const SComplex & j13 = j1[4*0+3];
const SComplex & j14 = j1[4*ATOOLS::Spinor<SType>::R1()+0];
const SComplex & j15 = j1[4*ATOOLS::Spinor<SType>::R1()+1];
const SComplex & j16 = j1[4*ATOOLS::Spinor<SType>::R1()+2];
const SComplex & j17 = j1[4*ATOOLS::Spinor<SType>::R1()+3];
const SComplex & j18 = j1[4*ATOOLS::Spinor<SType>::R2()+0];
const SComplex & j19 = j1[4*ATOOLS::Spinor<SType>::R2()+1];
const SComplex & j110 = j1[4*ATOOLS::Spinor<SType>::R2()+2];
const SComplex & j111 = j1[4*ATOOLS::Spinor<SType>::R2()+3];
const SComplex & j112 = j1[4*ATOOLS::Spinor<SType>::R3()+0];
const SComplex & j113 = j1[4*ATOOLS::Spinor<SType>::R3()+1];
const SComplex & j114 = j1[4*ATOOLS::Spinor<SType>::R3()+2];
const SComplex & j115 = j1[4*ATOOLS::Spinor<SType>::R3()+3];
const ATOOLS::Vec4D & p1 = p_v->J(1)->P();
const double& p10 = p1[0];
const double& p11 = p1[ATOOLS::Spinor<SType>::R1()];
const double& p12 = p1[ATOOLS::Spinor<SType>::R2()];
const double& p13 = p1[ATOOLS::Spinor<SType>::R3()];
CVec4<SType>* j2 = nullptr;
ATOOLS::Vec4D p2 = -p0-p1;
const double& p20 = p2[0];
const double& p21 = p2[ATOOLS::Spinor<SType>::R1()];
const double& p22 = p2[ATOOLS::Spinor<SType>::R2()];
const double& p23 = p2[ATOOLS::Spinor<SType>::R3()];
j2 = CVec4<SType>::New();
(*j2)[0] = j00*(-1.0*p11*j110 + 1.0*p12*j16 + 1.0*p13*j111 - 1.0*I*p13*j17 - 1.0*j115*(-1.0*I*p11 + 1.0*p12)) + j01*(1.0*p11*j111 - 1.0*p12*j17 + 1.0*p13*j110 + 1.0*I*p13*j16 - 1.0*j114*(1.0*I*p11 + 1.0*p12)) + j02*(-1.0*p11*j18 + 1.0*p12*j14 - 1.0*I*p13*j15 + 1.0*p13*j19 - 1.0*j113*(-1.0*I*p11 + 1.0*p12)) + j03*(1.0*p11*j19 - 1.0*p12*j15 + 1.0*I*p13*j14 + 1.0*p13*j18 - 1.0*j112*(1.0*I*p11 + 1.0*p12));
(*j2)[ATOOLS::Spinor<SType>::R1()] = j00*(1.0*I*p10*j115 + 1.0*p12*j114 + 1.0*p12*j12 - 1.0*I*p13*j13 - 1.0*j110*(1.0*p10 + 1.0*p13)) + j01*(-1.0*I*p10*j114 + 1.0*p12*j115 - 1.0*p12*j13 + 1.0*I*p13*j12 - 1.0*j111*(-1.0*p10 + 1.0*p13)) + j02*(1.0*I*p10*j113 + 1.0*p12*j10 - 1.0*p12*j112 - 1.0*I*p13*j11 - 1.0*j18*(1.0*p10 - 1.0*p13)) + j03*(-1.0*I*p10*j112 - 1.0*p12*j113 - 1.0*p12*j11 + 1.0*I*p13*j10 - 1.0*j19*(-1.0*p10 - 1.0*p13));
(*j2)[ATOOLS::Spinor<SType>::R2()] = j00*(-1.0*p10*j115 - 1.0*p11*j114 - 1.0*p11*j12 + 1.0*p13*j13 - 1.0*j16*(-1.0*p10 - 1.0*p13)) + j01*(-1.0*p10*j114 - 1.0*p11*j115 + 1.0*p11*j13 + 1.0*p13*j12 - 1.0*j17*(1.0*p10 - 1.0*p13)) + j02*(-1.0*p10*j113 - 1.0*p11*j10 + 1.0*p11*j112 + 1.0*p13*j11 - 1.0*j14*(-1.0*p10 + 1.0*p13)) + j03*(-1.0*p10*j112 + 1.0*p11*j113 + 1.0*p11*j11 + 1.0*p13*j10 - 1.0*j15*(1.0*p10 + 1.0*p13));
(*j2)[ATOOLS::Spinor<SType>::R3()] = j00*(1.0*p10*j111 - 1.0*I*p10*j17 + 1.0*p11*j110 - 1.0*p12*j16 + 1.0*j13*(1.0*I*p11 - 1.0*p12)) + j01*(1.0*p10*j110 + 1.0*I*p10*j16 + 1.0*p11*j111 - 1.0*p12*j17 + 1.0*j12*(-1.0*I*p11 - 1.0*p12)) + j02*(-1.0*I*p10*j15 + 1.0*p10*j19 - 1.0*p11*j18 + 1.0*p12*j14 + 1.0*j11*(1.0*I*p11 - 1.0*p12)) + j03*(1.0*I*p10*j14 + 1.0*p10*j18 - 1.0*p11*j19 + 1.0*p12*j15 + 1.0*j10*(-1.0*I*p11 - 1.0*p12));
j2->SetS(j0.S()|j1.S());
return j2;
}

      THROW(fatal_error, "Internal error in Lorentz calculator");
      return NULL;
    }

    virtual std::string FormFactor() const { return "None"; }


  };// end of class FRV1_Calculator

  template class FRV1_Calculator<double>;

}// end of namespace METOOLS


using namespace METOOLS;

DECLARE_GETTER(FRV1_Calculator<double>,"DFRV1",
	       Lorentz_Calculator,Vertex_Key);
Lorentz_Calculator *ATOOLS::Getter
<Lorentz_Calculator,Vertex_Key,FRV1_Calculator<double> >::
operator()(const Vertex_Key &key) const
{ return new FRV1_Calculator<double>(key); }

void ATOOLS::Getter<Lorentz_Calculator,Vertex_Key,
		    FRV1_Calculator<double> >::
PrintInfo(std::ostream &str,const size_t width) const
{ str<<"FRV1 vertex"; }
