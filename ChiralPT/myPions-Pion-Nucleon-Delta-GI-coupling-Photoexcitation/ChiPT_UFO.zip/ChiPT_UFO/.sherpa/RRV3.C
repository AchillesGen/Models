#include "METOOLS/Explicit/Lorentz_Calculator.H"
#include "METOOLS/Currents/C_Scalar.H"
#include "METOOLS/Currents/C_Spinor.H"
#include "METOOLS/Currents/C_Vector.H"
#include "METOOLS/Currents/C_RaritaSchwinger.H"
#include "METOOLS/Explicit/Vertex.H"
#include "METOOLS/Explicit/Form_Factor.H"
#include "MODEL/Main/Single_Vertex.H"
#include "ATOOLS/Org/Message.H"
#include "ATOOLS/Org/Exception.H"
#include "ATOOLS/Math/MyComplex.H"

namespace METOOLS {

  template <typename SType>
  class RRV3_Calculator: public Lorentz_Calculator {
  public:

    typedef std::complex<SType> SComplex;

    const SComplex I = SComplex(0.0,1.0);
    
    RRV3_Calculator(const Vertex_Key &key):
      Lorentz_Calculator(key) {

    }

    std::string Label() const { return "RRV3"; }

    CObject *Evaluate(const CObject_Vector &jj)
    {
// if outgoing index is 0
if (p_v->V()->id.back()==0) {
const CRaritaSchwinger<SType> & j1 = ((jj[0]->Get<CRaritaSchwinger<SType>>())->B() == -1 ? (*(jj[0]->Get<CRaritaSchwinger<SType>>())) : (*(jj[0]->Get<CRaritaSchwinger<SType>>())).CConj());
const SComplex & j10 = j1[4*0+0];
const SComplex & j11 = j1[4*0+1];
const SComplex & j12 = j1[4*0+2];
const SComplex & j13 = j1[4*0+3];
const SComplex & j14 = j1[4*ATOOLS::Spinor<SType>::R1()+0];
const SComplex & j15 = j1[4*ATOOLS::Spinor<SType>::R1()+1];
const SComplex & j16 = j1[4*ATOOLS::Spinor<SType>::R1()+2];
const SComplex & j17 = j1[4*ATOOLS::Spinor<SType>::R1()+3];
const SComplex & j18 = j1[4*ATOOLS::Spinor<SType>::R2()+0];
const SComplex & j19 = j1[4*ATOOLS::Spinor<SType>::R2()+1];
const SComplex & j110 = j1[4*ATOOLS::Spinor<SType>::R2()+2];
const SComplex & j111 = j1[4*ATOOLS::Spinor<SType>::R2()+3];
const SComplex & j112 = j1[4*ATOOLS::Spinor<SType>::R3()+0];
const SComplex & j113 = j1[4*ATOOLS::Spinor<SType>::R3()+1];
const SComplex & j114 = j1[4*ATOOLS::Spinor<SType>::R3()+2];
const SComplex & j115 = j1[4*ATOOLS::Spinor<SType>::R3()+3];
const CVec4<SType> & j2 = *(jj[1]->Get<CVec4<SType>>());
const SComplex & j20 = j2[0];
const SComplex & j21 = j2[ATOOLS::Spinor<SType>::R1()];
const SComplex & j22 = j2[ATOOLS::Spinor<SType>::R2()];
const SComplex & j23 = j2[ATOOLS::Spinor<SType>::R3()];
CRaritaSchwinger<SType>* j0 = nullptr;
j0 = CRaritaSchwinger<SType>::New(m_r[0],-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
(*j0)[0*4+0] = 1.0*j20*(2.0*I*j111 + 2.0*j114 + 3.0*j12 + 2.0*j17) - 1.0*j21*(-1.0*I*j110 - 1.0*j115 + 1.0*j13 + 2.0*j16) - 1.0*j22*(2.0*j110 - 1.0*I*j115 + 1.0*I*j13 + 1.0*I*j16) - 1.0*j23*(1.0*I*j111 + 2.0*j114 + 1.0*j12 + 1.0*j17);
(*j0)[0*4+1] = 1.0*j20*(-2.0*I*j110 - 2.0*j115 + 3.0*j13 + 2.0*j16) - 1.0*j21*(1.0*I*j111 + 1.0*j114 + 1.0*j12 + 2.0*j17) - 1.0*j22*(2.0*j111 - 1.0*I*j114 - 1.0*I*j12 - 1.0*I*j17) - 1.0*j23*(1.0*I*j110 + 2.0*j115 - 1.0*j13 - 1.0*j16);
(*j0)[0*4+2] = 1.0*j20*(3.0*j10 - 2.0*j112 - 2.0*j15 - 2.0*I*j19) - 1.0*j21*(-1.0*j113 - 1.0*j11 + 2.0*j14 - 1.0*I*j18) - 1.0*j22*(-1.0*I*j113 - 1.0*I*j11 + 1.0*I*j14 + 2.0*j18) - 1.0*j23*(-1.0*j10 + 2.0*j112 + 1.0*j15 + 1.0*I*j19);
(*j0)[0*4+3] = 1.0*j20*(2.0*j113 + 3.0*j11 - 2.0*j14 + 2.0*I*j18) - 1.0*j21*(-1.0*j10 + 1.0*j112 + 2.0*j15 + 1.0*I*j19) - 1.0*j22*(1.0*I*j10 - 1.0*I*j112 - 1.0*I*j15 + 2.0*j19) - 1.0*j23*(2.0*j113 + 1.0*j11 - 1.0*j14 + 1.0*I*j18);
(*j0)[ATOOLS::Spinor<SType>::R1()*4+0] = 1.0*j20*(1.0*I*j110 + 1.0*j115 - 2.0*j13 - 1.0*j16) - 1.0*j21*(-2.0*I*j111 - 2.0*j114 - 2.0*j12 - 3.0*j17) - 1.0*j22*(-2.0*j111 + 1.0*I*j114 + 1.0*I*j12 + 1.0*I*j17) - 1.0*j23*(-1.0*I*j110 - 2.0*j115 + 1.0*j13 + 1.0*j16);
(*j0)[ATOOLS::Spinor<SType>::R1()*4+1] = 1.0*j20*(-1.0*I*j111 - 1.0*j114 - 2.0*j12 - 1.0*j17) - 1.0*j21*(2.0*I*j110 + 2.0*j115 - 2.0*j13 - 3.0*j16) - 1.0*j22*(-2.0*j110 + 1.0*I*j115 - 1.0*I*j13 - 1.0*I*j16) - 1.0*j23*(-1.0*I*j111 - 2.0*j114 - 1.0*j12 - 1.0*j17);
(*j0)[ATOOLS::Spinor<SType>::R1()*4+2] = 1.0*j20*(1.0*j113 + 2.0*j11 - 1.0*j14 + 1.0*I*j18) - 1.0*j21*(-2.0*j10 + 2.0*j112 + 3.0*j15 + 2.0*I*j19) - 1.0*j22*(1.0*I*j10 - 1.0*I*j112 - 1.0*I*j15 + 2.0*j19) - 1.0*j23*(2.0*j113 + 1.0*j11 - 1.0*j14 + 1.0*I*j18);
(*j0)[ATOOLS::Spinor<SType>::R1()*4+3] = 1.0*j20*(2.0*j10 - 1.0*j112 - 1.0*j15 - 1.0*I*j19) - 1.0*j21*(-2.0*j113 - 2.0*j11 + 3.0*j14 - 2.0*I*j18) - 1.0*j22*(-1.0*I*j113 - 1.0*I*j11 + 1.0*I*j14 + 2.0*j18) - 1.0*j23*(-1.0*j10 + 2.0*j112 + 1.0*j15 + 1.0*I*j19);
(*j0)[ATOOLS::Spinor<SType>::R2()*4+0] = 1.0*j20*(-1.0*j110 + 1.0*I*j115 - 2.0*I*j13 - 1.0*I*j16) - 1.0*j21*(1.0*j111 - 1.0*I*j114 - 1.0*I*j12 - 2.0*I*j17) - 1.0*j22*(-3.0*I*j111 - 2.0*j114 - 2.0*j12 - 2.0*j17) - 1.0*j23*(1.0*j110 - 2.0*I*j115 + 1.0*I*j13 + 1.0*I*j16);
(*j0)[ATOOLS::Spinor<SType>::R2()*4+1] = 1.0*j20*(-1.0*j111 + 1.0*I*j114 + 2.0*I*j12 + 1.0*I*j17) - 1.0*j21*(1.0*j110 - 1.0*I*j115 + 1.0*I*j13 + 2.0*I*j16) - 1.0*j22*(3.0*I*j110 + 2.0*j115 - 2.0*j13 - 2.0*j16) - 1.0*j23*(-1.0*j111 + 2.0*I*j114 + 1.0*I*j12 + 1.0*I*j17);
(*j0)[ATOOLS::Spinor<SType>::R2()*4+2] = 1.0*j20*(1.0*I*j113 + 2.0*I*j11 - 1.0*I*j14 - 1.0*j18) - 1.0*j21*(-1.0*I*j10 + 1.0*I*j112 + 2.0*I*j15 - 1.0*j19) - 1.0*j22*(-2.0*j10 + 2.0*j112 + 2.0*j15 + 3.0*I*j19) - 1.0*j23*(2.0*I*j113 + 1.0*I*j11 - 1.0*I*j14 - 1.0*j18);
(*j0)[ATOOLS::Spinor<SType>::R2()*4+3] = 1.0*j20*(-2.0*I*j10 + 1.0*I*j112 + 1.0*I*j15 - 1.0*j19) - 1.0*j21*(1.0*I*j113 + 1.0*I*j11 - 2.0*I*j14 - 1.0*j18) - 1.0*j22*(-2.0*j113 - 2.0*j11 + 2.0*j14 - 3.0*I*j18) - 1.0*j23*(1.0*I*j10 - 2.0*I*j112 - 1.0*I*j15 + 1.0*j19);
(*j0)[ATOOLS::Spinor<SType>::R3()*4+0] = 1.0*j20*(-1.0*I*j111 - 1.0*j114 - 2.0*j12 - 1.0*j17) - 1.0*j21*(1.0*I*j110 + 1.0*j115 - 1.0*j13 - 2.0*j16) - 1.0*j22*(-2.0*j110 + 1.0*I*j115 - 1.0*I*j13 - 1.0*I*j16) - 1.0*j23*(-2.0*I*j111 - 3.0*j114 - 2.0*j12 - 2.0*j17);
(*j0)[ATOOLS::Spinor<SType>::R3()*4+1] = 1.0*j20*(-1.0*I*j110 - 1.0*j115 + 2.0*j13 + 1.0*j16) - 1.0*j21*(1.0*I*j111 + 1.0*j114 + 1.0*j12 + 2.0*j17) - 1.0*j22*(2.0*j111 - 1.0*I*j114 - 1.0*I*j12 - 1.0*I*j17) - 1.0*j23*(2.0*I*j110 + 3.0*j115 - 2.0*j13 - 2.0*j16);
(*j0)[ATOOLS::Spinor<SType>::R3()*4+2] = 1.0*j20*(2.0*j10 - 1.0*j112 - 1.0*j15 - 1.0*I*j19) - 1.0*j21*(-1.0*j113 - 1.0*j11 + 2.0*j14 - 1.0*I*j18) - 1.0*j22*(-1.0*I*j113 - 1.0*I*j11 + 1.0*I*j14 + 2.0*j18) - 1.0*j23*(-2.0*j10 + 3.0*j112 + 2.0*j15 + 2.0*I*j19);
(*j0)[ATOOLS::Spinor<SType>::R3()*4+3] = 1.0*j20*(-1.0*j113 - 2.0*j11 + 1.0*j14 - 1.0*I*j18) - 1.0*j21*(1.0*j10 - 1.0*j112 - 2.0*j15 - 1.0*I*j19) - 1.0*j22*(-1.0*I*j10 + 1.0*I*j112 + 1.0*I*j15 - 2.0*j19) - 1.0*j23*(-3.0*j113 - 2.0*j11 + 2.0*j14 - 2.0*I*j18);
j0->SetS(j1.S()|j2.S());
return j0;
}
// if outgoing index is 1
if (p_v->V()->id.back()==1) {
const CRaritaSchwinger<SType> & j0 = ((jj[1]->Get<CRaritaSchwinger<SType>>())->B() == 1 ? (*(jj[1]->Get<CRaritaSchwinger<SType>>())) : (*(jj[1]->Get<CRaritaSchwinger<SType>>())).CConj());
const SComplex & j00 = j0[4*0+0];
const SComplex & j01 = j0[4*0+1];
const SComplex & j02 = j0[4*0+2];
const SComplex & j03 = j0[4*0+3];
const SComplex & j04 = j0[4*ATOOLS::Spinor<SType>::R1()+0];
const SComplex & j05 = j0[4*ATOOLS::Spinor<SType>::R1()+1];
const SComplex & j06 = j0[4*ATOOLS::Spinor<SType>::R1()+2];
const SComplex & j07 = j0[4*ATOOLS::Spinor<SType>::R1()+3];
const SComplex & j08 = j0[4*ATOOLS::Spinor<SType>::R2()+0];
const SComplex & j09 = j0[4*ATOOLS::Spinor<SType>::R2()+1];
const SComplex & j010 = j0[4*ATOOLS::Spinor<SType>::R2()+2];
const SComplex & j011 = j0[4*ATOOLS::Spinor<SType>::R2()+3];
const SComplex & j012 = j0[4*ATOOLS::Spinor<SType>::R3()+0];
const SComplex & j013 = j0[4*ATOOLS::Spinor<SType>::R3()+1];
const SComplex & j014 = j0[4*ATOOLS::Spinor<SType>::R3()+2];
const SComplex & j015 = j0[4*ATOOLS::Spinor<SType>::R3()+3];
const CVec4<SType> & j2 = *(jj[0]->Get<CVec4<SType>>());
const SComplex & j20 = j2[0];
const SComplex & j21 = j2[ATOOLS::Spinor<SType>::R1()];
const SComplex & j22 = j2[ATOOLS::Spinor<SType>::R2()];
const SComplex & j23 = j2[ATOOLS::Spinor<SType>::R3()];
CRaritaSchwinger<SType>* j1 = nullptr;
j1 = CRaritaSchwinger<SType>::New(m_r[1],1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
(*j1)[0*4+0] = 1.0*j20*(2.0*I*j011 - 2.0*j014 + 3.0*j02 - 2.0*j07) - 1.0*j21*(1.0*I*j010 - 1.0*j015 - 1.0*j03 + 2.0*j06) - 1.0*j22*(2.0*j010 + 1.0*I*j015 + 1.0*I*j03 - 1.0*I*j06) - 1.0*j23*(-1.0*I*j011 + 2.0*j014 - 1.0*j02 + 1.0*j07);
(*j1)[0*4+1] = 1.0*j20*(-2.0*I*j010 + 2.0*j015 + 3.0*j03 - 2.0*j06) - 1.0*j21*(-1.0*I*j011 + 1.0*j014 - 1.0*j02 + 2.0*j07) - 1.0*j22*(2.0*j011 + 1.0*I*j014 - 1.0*I*j02 + 1.0*I*j07) - 1.0*j23*(-1.0*I*j010 + 2.0*j015 + 1.0*j03 - 1.0*j06);
(*j1)[0*4+2] = 1.0*j20*(3.0*j00 + 2.0*j012 + 2.0*j05 - 2.0*I*j09) - 1.0*j21*(-1.0*j013 + 1.0*j01 + 2.0*j04 + 1.0*I*j08) - 1.0*j22*(1.0*I*j013 - 1.0*I*j01 - 1.0*I*j04 + 2.0*j08) - 1.0*j23*(1.0*j00 + 2.0*j012 + 1.0*j05 - 1.0*I*j09);
(*j1)[0*4+3] = 1.0*j20*(-2.0*j013 + 3.0*j01 + 2.0*j04 + 2.0*I*j08) - 1.0*j21*(1.0*j00 + 1.0*j012 + 2.0*j05 - 1.0*I*j09) - 1.0*j22*(1.0*I*j00 + 1.0*I*j012 + 1.0*I*j05 + 2.0*j09) - 1.0*j23*(2.0*j013 - 1.0*j01 - 1.0*j04 - 1.0*I*j08);
(*j1)[ATOOLS::Spinor<SType>::R1()*4+0] = 1.0*j20*(-1.0*I*j010 + 1.0*j015 + 2.0*j03 - 1.0*j06) - 1.0*j21*(-2.0*I*j011 + 2.0*j014 - 2.0*j02 + 3.0*j07) - 1.0*j22*(2.0*j011 + 1.0*I*j014 - 1.0*I*j02 + 1.0*I*j07) - 1.0*j23*(-1.0*I*j010 + 2.0*j015 + 1.0*j03 - 1.0*j06);
(*j1)[ATOOLS::Spinor<SType>::R1()*4+1] = 1.0*j20*(1.0*I*j011 - 1.0*j014 + 2.0*j02 - 1.0*j07) - 1.0*j21*(2.0*I*j010 - 2.0*j015 - 2.0*j03 + 3.0*j06) - 1.0*j22*(2.0*j010 + 1.0*I*j015 + 1.0*I*j03 - 1.0*I*j06) - 1.0*j23*(-1.0*I*j011 + 2.0*j014 - 1.0*j02 + 1.0*j07);
(*j1)[ATOOLS::Spinor<SType>::R1()*4+2] = 1.0*j20*(1.0*j013 - 2.0*j01 - 1.0*j04 - 1.0*I*j08) - 1.0*j21*(-2.0*j00 - 2.0*j012 - 3.0*j05 + 2.0*I*j09) - 1.0*j22*(-1.0*I*j00 - 1.0*I*j012 - 1.0*I*j05 - 2.0*j09) - 1.0*j23*(-2.0*j013 + 1.0*j01 + 1.0*j04 + 1.0*I*j08);
(*j1)[ATOOLS::Spinor<SType>::R1()*4+3] = 1.0*j20*(-2.0*j00 - 1.0*j012 - 1.0*j05 + 1.0*I*j09) - 1.0*j21*(2.0*j013 - 2.0*j01 - 3.0*j04 - 2.0*I*j08) - 1.0*j22*(-1.0*I*j013 + 1.0*I*j01 + 1.0*I*j04 - 2.0*j08) - 1.0*j23*(-1.0*j00 - 2.0*j012 - 1.0*j05 + 1.0*I*j09);
(*j1)[ATOOLS::Spinor<SType>::R2()*4+0] = 1.0*j20*(-1.0*j010 - 1.0*I*j015 - 2.0*I*j03 + 1.0*I*j06) - 1.0*j21*(-1.0*j011 - 1.0*I*j014 + 1.0*I*j02 - 2.0*I*j07) - 1.0*j22*(-3.0*I*j011 + 2.0*j014 - 2.0*j02 + 2.0*j07) - 1.0*j23*(-1.0*j010 - 2.0*I*j015 - 1.0*I*j03 + 1.0*I*j06);
(*j1)[ATOOLS::Spinor<SType>::R2()*4+1] = 1.0*j20*(-1.0*j011 - 1.0*I*j014 + 2.0*I*j02 - 1.0*I*j07) - 1.0*j21*(-1.0*j010 - 1.0*I*j015 - 1.0*I*j03 + 2.0*I*j06) - 1.0*j22*(3.0*I*j010 - 2.0*j015 - 2.0*j03 + 2.0*j06) - 1.0*j23*(1.0*j011 + 2.0*I*j014 - 1.0*I*j02 + 1.0*I*j07);
(*j1)[ATOOLS::Spinor<SType>::R2()*4+2] = 1.0*j20*(-1.0*I*j013 + 2.0*I*j01 + 1.0*I*j04 - 1.0*j08) - 1.0*j21*(1.0*I*j00 + 1.0*I*j012 + 2.0*I*j05 + 1.0*j09) - 1.0*j22*(-2.0*j00 - 2.0*j012 - 2.0*j05 + 3.0*I*j09) - 1.0*j23*(2.0*I*j013 - 1.0*I*j01 - 1.0*I*j04 + 1.0*j08);
(*j1)[ATOOLS::Spinor<SType>::R2()*4+3] = 1.0*j20*(-2.0*I*j00 - 1.0*I*j012 - 1.0*I*j05 - 1.0*j09) - 1.0*j21*(1.0*I*j013 - 1.0*I*j01 - 2.0*I*j04 + 1.0*j08) - 1.0*j22*(2.0*j013 - 2.0*j01 - 2.0*j04 - 3.0*I*j08) - 1.0*j23*(-1.0*I*j00 - 2.0*I*j012 - 1.0*I*j05 - 1.0*j09);
(*j1)[ATOOLS::Spinor<SType>::R3()*4+0] = 1.0*j20*(1.0*I*j011 - 1.0*j014 + 2.0*j02 - 1.0*j07) - 1.0*j21*(1.0*I*j010 - 1.0*j015 - 1.0*j03 + 2.0*j06) - 1.0*j22*(2.0*j010 + 1.0*I*j015 + 1.0*I*j03 - 1.0*I*j06) - 1.0*j23*(-2.0*I*j011 + 3.0*j014 - 2.0*j02 + 2.0*j07);
(*j1)[ATOOLS::Spinor<SType>::R3()*4+1] = 1.0*j20*(1.0*I*j010 - 1.0*j015 - 2.0*j03 + 1.0*j06) - 1.0*j21*(1.0*I*j011 - 1.0*j014 + 1.0*j02 - 2.0*j07) - 1.0*j22*(-2.0*j011 - 1.0*I*j014 + 1.0*I*j02 - 1.0*I*j07) - 1.0*j23*(2.0*I*j010 - 3.0*j015 - 2.0*j03 + 2.0*j06);
(*j1)[ATOOLS::Spinor<SType>::R3()*4+2] = 1.0*j20*(-2.0*j00 - 1.0*j012 - 1.0*j05 + 1.0*I*j09) - 1.0*j21*(1.0*j013 - 1.0*j01 - 2.0*j04 - 1.0*I*j08) - 1.0*j22*(-1.0*I*j013 + 1.0*I*j01 + 1.0*I*j04 - 2.0*j08) - 1.0*j23*(-2.0*j00 - 3.0*j012 - 2.0*j05 + 2.0*I*j09);
(*j1)[ATOOLS::Spinor<SType>::R3()*4+3] = 1.0*j20*(-1.0*j013 + 2.0*j01 + 1.0*j04 + 1.0*I*j08) - 1.0*j21*(1.0*j00 + 1.0*j012 + 2.0*j05 - 1.0*I*j09) - 1.0*j22*(1.0*I*j00 + 1.0*I*j012 + 1.0*I*j05 + 2.0*j09) - 1.0*j23*(3.0*j013 - 2.0*j01 - 2.0*j04 - 2.0*I*j08);
j1->SetS(j0.S()|j2.S());
return j1;
}
// if outgoing index is 2
if (p_v->V()->id.back()==2) {
const CRaritaSchwinger<SType> & j0 = ((jj[0]->Get<CRaritaSchwinger<SType>>())->B() == 1 ? (*(jj[0]->Get<CRaritaSchwinger<SType>>())) : (*(jj[0]->Get<CRaritaSchwinger<SType>>())).CConj());
const SComplex & j00 = j0[4*0+0];
const SComplex & j01 = j0[4*0+1];
const SComplex & j02 = j0[4*0+2];
const SComplex & j03 = j0[4*0+3];
const SComplex & j04 = j0[4*ATOOLS::Spinor<SType>::R1()+0];
const SComplex & j05 = j0[4*ATOOLS::Spinor<SType>::R1()+1];
const SComplex & j06 = j0[4*ATOOLS::Spinor<SType>::R1()+2];
const SComplex & j07 = j0[4*ATOOLS::Spinor<SType>::R1()+3];
const SComplex & j08 = j0[4*ATOOLS::Spinor<SType>::R2()+0];
const SComplex & j09 = j0[4*ATOOLS::Spinor<SType>::R2()+1];
const SComplex & j010 = j0[4*ATOOLS::Spinor<SType>::R2()+2];
const SComplex & j011 = j0[4*ATOOLS::Spinor<SType>::R2()+3];
const SComplex & j012 = j0[4*ATOOLS::Spinor<SType>::R3()+0];
const SComplex & j013 = j0[4*ATOOLS::Spinor<SType>::R3()+1];
const SComplex & j014 = j0[4*ATOOLS::Spinor<SType>::R3()+2];
const SComplex & j015 = j0[4*ATOOLS::Spinor<SType>::R3()+3];
const CRaritaSchwinger<SType> & j1 = ((jj[1]->Get<CRaritaSchwinger<SType>>())->B() == -1 ? (*(jj[1]->Get<CRaritaSchwinger<SType>>())) : (*(jj[1]->Get<CRaritaSchwinger<SType>>())).CConj());
const SComplex & j10 = j1[4*0+0];
const SComplex & j11 = j1[4*0+1];
const SComplex & j12 = j1[4*0+2];
const SComplex & j13 = j1[4*0+3];
const SComplex & j14 = j1[4*ATOOLS::Spinor<SType>::R1()+0];
const SComplex & j15 = j1[4*ATOOLS::Spinor<SType>::R1()+1];
const SComplex & j16 = j1[4*ATOOLS::Spinor<SType>::R1()+2];
const SComplex & j17 = j1[4*ATOOLS::Spinor<SType>::R1()+3];
const SComplex & j18 = j1[4*ATOOLS::Spinor<SType>::R2()+0];
const SComplex & j19 = j1[4*ATOOLS::Spinor<SType>::R2()+1];
const SComplex & j110 = j1[4*ATOOLS::Spinor<SType>::R2()+2];
const SComplex & j111 = j1[4*ATOOLS::Spinor<SType>::R2()+3];
const SComplex & j112 = j1[4*ATOOLS::Spinor<SType>::R3()+0];
const SComplex & j113 = j1[4*ATOOLS::Spinor<SType>::R3()+1];
const SComplex & j114 = j1[4*ATOOLS::Spinor<SType>::R3()+2];
const SComplex & j115 = j1[4*ATOOLS::Spinor<SType>::R3()+3];
CVec4<SType>* j2 = nullptr;
j2 = CVec4<SType>::New();
(*j2)[0] = 1.0*j10*(2.0*I*j011 - 2.0*j014 + 3.0*j02 - 2.0*j07) - 1.0*j110*(-1.0*I*j013 + 2.0*I*j01 + 1.0*I*j04 - 1.0*j08) - 1.0*j111*(-2.0*I*j00 - 1.0*I*j012 - 1.0*I*j05 - 1.0*j09) - 1.0*j112*(1.0*I*j011 - 1.0*j014 + 2.0*j02 - 1.0*j07) - 1.0*j113*(1.0*I*j010 - 1.0*j015 - 2.0*j03 + 1.0*j06) - 1.0*j114*(-2.0*j00 - 1.0*j012 - 1.0*j05 + 1.0*I*j09) - 1.0*j115*(-1.0*j013 + 2.0*j01 + 1.0*j04 + 1.0*I*j08) + 1.0*j11*(-2.0*I*j010 + 2.0*j015 + 3.0*j03 - 2.0*j06) + 1.0*j12*(3.0*j00 + 2.0*j012 + 2.0*j05 - 2.0*I*j09) + 1.0*j13*(-2.0*j013 + 3.0*j01 + 2.0*j04 + 2.0*I*j08) - 1.0*j14*(-1.0*I*j010 + 1.0*j015 + 2.0*j03 - 1.0*j06) - 1.0*j15*(1.0*I*j011 - 1.0*j014 + 2.0*j02 - 1.0*j07) - 1.0*j16*(1.0*j013 - 2.0*j01 - 1.0*j04 - 1.0*I*j08) - 1.0*j17*(-2.0*j00 - 1.0*j012 - 1.0*j05 + 1.0*I*j09) - 1.0*j18*(-1.0*j010 - 1.0*I*j015 - 2.0*I*j03 + 1.0*I*j06) - 1.0*j19*(-1.0*j011 - 1.0*I*j014 + 2.0*I*j02 - 1.0*I*j07);
(*j2)[ATOOLS::Spinor<SType>::R1()] = 1.0*j10*(1.0*I*j010 - 1.0*j015 - 1.0*j03 + 2.0*j06) - 1.0*j110*(1.0*I*j00 + 1.0*I*j012 + 2.0*I*j05 + 1.0*j09) - 1.0*j111*(1.0*I*j013 - 1.0*I*j01 - 2.0*I*j04 + 1.0*j08) - 1.0*j112*(1.0*I*j010 - 1.0*j015 - 1.0*j03 + 2.0*j06) - 1.0*j113*(1.0*I*j011 - 1.0*j014 + 1.0*j02 - 2.0*j07) - 1.0*j114*(1.0*j013 - 1.0*j01 - 2.0*j04 - 1.0*I*j08) - 1.0*j115*(1.0*j00 + 1.0*j012 + 2.0*j05 - 1.0*I*j09) + 1.0*j11*(-1.0*I*j011 + 1.0*j014 - 1.0*j02 + 2.0*j07) + 1.0*j12*(-1.0*j013 + 1.0*j01 + 2.0*j04 + 1.0*I*j08) + 1.0*j13*(1.0*j00 + 1.0*j012 + 2.0*j05 - 1.0*I*j09) - 1.0*j14*(-2.0*I*j011 + 2.0*j014 - 2.0*j02 + 3.0*j07) - 1.0*j15*(2.0*I*j010 - 2.0*j015 - 2.0*j03 + 3.0*j06) - 1.0*j16*(-2.0*j00 - 2.0*j012 - 3.0*j05 + 2.0*I*j09) - 1.0*j17*(2.0*j013 - 2.0*j01 - 3.0*j04 - 2.0*I*j08) - 1.0*j18*(-1.0*j011 - 1.0*I*j014 + 1.0*I*j02 - 2.0*I*j07) - 1.0*j19*(-1.0*j010 - 1.0*I*j015 - 1.0*I*j03 + 2.0*I*j06);
(*j2)[ATOOLS::Spinor<SType>::R2()] = 1.0*j10*(2.0*j010 + 1.0*I*j015 + 1.0*I*j03 - 1.0*I*j06) - 1.0*j110*(-2.0*j00 - 2.0*j012 - 2.0*j05 + 3.0*I*j09) - 1.0*j111*(2.0*j013 - 2.0*j01 - 2.0*j04 - 3.0*I*j08) - 1.0*j112*(2.0*j010 + 1.0*I*j015 + 1.0*I*j03 - 1.0*I*j06) - 1.0*j113*(-2.0*j011 - 1.0*I*j014 + 1.0*I*j02 - 1.0*I*j07) - 1.0*j114*(-1.0*I*j013 + 1.0*I*j01 + 1.0*I*j04 - 2.0*j08) - 1.0*j115*(1.0*I*j00 + 1.0*I*j012 + 1.0*I*j05 + 2.0*j09) + 1.0*j11*(2.0*j011 + 1.0*I*j014 - 1.0*I*j02 + 1.0*I*j07) + 1.0*j12*(1.0*I*j013 - 1.0*I*j01 - 1.0*I*j04 + 2.0*j08) + 1.0*j13*(1.0*I*j00 + 1.0*I*j012 + 1.0*I*j05 + 2.0*j09) - 1.0*j14*(2.0*j011 + 1.0*I*j014 - 1.0*I*j02 + 1.0*I*j07) - 1.0*j15*(2.0*j010 + 1.0*I*j015 + 1.0*I*j03 - 1.0*I*j06) - 1.0*j16*(-1.0*I*j00 - 1.0*I*j012 - 1.0*I*j05 - 2.0*j09) - 1.0*j17*(-1.0*I*j013 + 1.0*I*j01 + 1.0*I*j04 - 2.0*j08) - 1.0*j18*(-3.0*I*j011 + 2.0*j014 - 2.0*j02 + 2.0*j07) - 1.0*j19*(3.0*I*j010 - 2.0*j015 - 2.0*j03 + 2.0*j06);
(*j2)[ATOOLS::Spinor<SType>::R3()] = 1.0*j10*(-1.0*I*j011 + 2.0*j014 - 1.0*j02 + 1.0*j07) - 1.0*j110*(2.0*I*j013 - 1.0*I*j01 - 1.0*I*j04 + 1.0*j08) - 1.0*j111*(-1.0*I*j00 - 2.0*I*j012 - 1.0*I*j05 - 1.0*j09) - 1.0*j112*(-2.0*I*j011 + 3.0*j014 - 2.0*j02 + 2.0*j07) - 1.0*j113*(2.0*I*j010 - 3.0*j015 - 2.0*j03 + 2.0*j06) - 1.0*j114*(-2.0*j00 - 3.0*j012 - 2.0*j05 + 2.0*I*j09) - 1.0*j115*(3.0*j013 - 2.0*j01 - 2.0*j04 - 2.0*I*j08) + 1.0*j11*(-1.0*I*j010 + 2.0*j015 + 1.0*j03 - 1.0*j06) + 1.0*j12*(1.0*j00 + 2.0*j012 + 1.0*j05 - 1.0*I*j09) + 1.0*j13*(2.0*j013 - 1.0*j01 - 1.0*j04 - 1.0*I*j08) - 1.0*j14*(-1.0*I*j010 + 2.0*j015 + 1.0*j03 - 1.0*j06) - 1.0*j15*(-1.0*I*j011 + 2.0*j014 - 1.0*j02 + 1.0*j07) - 1.0*j16*(-2.0*j013 + 1.0*j01 + 1.0*j04 + 1.0*I*j08) - 1.0*j17*(-1.0*j00 - 2.0*j012 - 1.0*j05 + 1.0*I*j09) - 1.0*j18*(-1.0*j010 - 2.0*I*j015 - 1.0*I*j03 + 1.0*I*j06) - 1.0*j19*(1.0*j011 + 2.0*I*j014 - 1.0*I*j02 + 1.0*I*j07);
j2->SetS(j0.S()|j1.S());
return j2;
}

      THROW(fatal_error, "Internal error in Lorentz calculator");
      return NULL;
    }

    virtual std::string FormFactor() const { return "None"; }


  };// end of class RRV3_Calculator

  template class RRV3_Calculator<double>;

}// end of namespace METOOLS


using namespace METOOLS;

DECLARE_GETTER(RRV3_Calculator<double>,"DRRV3",
	       Lorentz_Calculator,Vertex_Key);
Lorentz_Calculator *ATOOLS::Getter
<Lorentz_Calculator,Vertex_Key,RRV3_Calculator<double> >::
operator()(const Vertex_Key &key) const
{ return new RRV3_Calculator<double>(key); }

void ATOOLS::Getter<Lorentz_Calculator,Vertex_Key,
		    RRV3_Calculator<double> >::
PrintInfo(std::ostream &str,const size_t width) const
{ str<<"RRV3 vertex"; }
